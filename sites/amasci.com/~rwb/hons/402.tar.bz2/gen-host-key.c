/* gen-host-key.c - generate a new private and public key pair for the host */
/* Richard Bean, 13 November 1997 */

#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "usuals.h"
#include "mpilib.h"
#include "rsaglue.h"
#include "rsagen.h"
#include "keymgmt.h"

FILE *pgpout = stderr; /* PGP error messages go to standard error */
main()
{
	/* this function gets the hostname, generates a public key
	   and writes the private key to the file <hostname> and
	   the public key to the file <hostname>.pub */

	char host[100]; /* for the hostname */
	byte timestamp = 0, userid = 0; /* timestamp and userid */
	int status; /* return status for rsa_keygen() */
	short keybits = 512; /* military grade */
	short ebits = 0; /* let derive function decide length */
	unit n[MAX_UNIT_PRECISION], e[MAX_UNIT_PRECISION],
	d[MAX_UNIT_PRECISION], p[MAX_UNIT_PRECISION],
	q[MAX_UNIT_PRECISION], u[MAX_UNIT_PRECISION]; /* private key parameters */
	boolean seedfileexists=seedfile_exists(); /* check if seed file exists - ``randseed.bin'' */
	gethostname(host,100); /* get this host's name */
	if ((status=rsa_keygen(n,e,d,p,q,u,keybits,ebits))<0)
	{
		printf("rsa_keygen failed %d\n",status);
		exit(0);
	}

	/* print out the key parameters */
	fprintf(stderr,"Key ID %s\n", key2IDstring(n));
	mp_display(" modulus n = ",n);
	mp_display("exponent e = ",e);
	mp_display("exponent d = ",d);
	mp_display("   prime p = ",p);
	mp_display("   prime q = ",q);
	mp_display(" inverse u = ",u);

	/* write the private key to a file */
	writekeyfile(host, 0, &timestamp, &userid, n, e, d, p, q, u);

	/* now set d to 0 and it will just write out the public key */
	strcat(host,".pub");
	writekeyfile(host, 0, &timestamp, &userid, n, e, NULL, NULL, NULL, NULL);
	if (!seedfileexists)
		create_seedfile(); /* create seed file if it doesn't exist */
	return 0;
}
