/* der-cap.c - derives a capability given the object capability */
/* Richard Bean, 13 November 1997 */

#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "amoeba.h"

rights_bits string2rights(char string[8])
{
	/* this function takes an 8-character string of 0s and 1s 
	   representing a binary number and translates it to an integer 
	   that could be used in a request */
	/* a call to strtol(string,NULL,2) would also work */
	rights_bits x=0;
	int i,j=128;
	for (i=8; i; i--,j>>=1)
		if (string[8-i] == '1')
			x += j;
	return x;
}

main(int argc, char **argv)
{
	/* this function takes the command line arguments
	   of the owner capability filename, the derived capability
	   filename, and the rights bits which the derived
	   capability should have set.  It then uses prv_encode()
	   to generate a new capability with the appropriate rights
	   bits set. */
	   
	char host[10],cap1[10],cap2[10],cap3[10];
	int status;
	FILE *f;
	port cap_port; /* for when we write it back... unused server port */
	private prv; /* the private part of the capability */
	char obj1[3]; /* obj number read straight from file */
	objnum obj; /* obj number in integer form */ 
	rights_bits rights,oldrights; /* new and old rights */
	port random; /* arguments to prv_encode */
	int num; /* for result of prv_encode() */

	if (argc != 4)
	{
		printf("usage: der-cap <original cap> <derived cap> <rights>\n");
		exit(1);
	}

	rights = string2rights(argv[3]); /* get rights bits */

	/* read in the original owner capability */
	f = fopen(argv[1], "r");
	fread(&cap_port,1,6,f); /* read the server port */
	fread(&obj1,1,3,f); /* read the object number */
	_buf_get_long(&obj1,&obj1+3,&obj);
	fread(&oldrights,1,1,f); /* read rights_bits (= 0xff) */
	fread(&random,1,6,f); /* the check field for the owner capability */
	fclose(f);
	
	/* create the new capability */
	num = _prv_encode(&prv, obj, rights, &random);
	if (num != 0) 
	{
		printf("prv_encode() failed\n");
		exit(1);
	}

	/* write out new derived capability */
	f = fopen(argv[2], "w");
	fwrite(&cap_port,1,6,f); /* server port - not examined */
	fwrite(&prv,1,10,f); /* our new private part of the capability */
	fclose(f);

	return 0;
}
