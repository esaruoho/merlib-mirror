/* dec.c - run prv_decode() 100,000 times to run the one-way
   function this many times, then time the result by running
   using ``time ./dec'' */
/* Richard Bean, 13 November 1997 */

#include "amoeba.h"

#define THOUSAND 1000
#define BIGNUM2 100
main()
{
	long i,j;
	private prv;
	rights_bits prights;
	port random;
	prv.prv_random._portbytes[0] = 1; /* non-zero */
	prv.prv_rights = 254; /* something not all 1's */
	random._portbytes[0] = 1; /* non-zero */
	for (i = 0; i < THOUSAND; i++)
		for (j = 0; j < BIGNUM2; j++)
		_prv_decode(&prv, &prights, &random);
}
