/* gen-cap.c - generates capabilities for the host */
/* Richard Bean, 13 November 1997 */

#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "usuals.h"
#include "mpilib.h"
#include "rsaglue.h"
#include "rsagen.h"
#include "keymgmt.h"

main()
{
	/* this function generates three owner capabilities
	   for the three objects that are on each server */

	char host[10],cap1[10],cap2[10],cap3[10]; /* hostname, filenames */
	char b[4]; /* obj num - use _buf_put_long to put objnum in */
	FILE *f; /* file pointer */
	byte y = 0xff; /* all rights set */
	byte a[48]; /* our new random number - 48 bits = 6 bytes used */
	gethostname(host,4); /* get our hostname's first 3 characters */

	strcpy(cap1,host);
	strcat(cap1,".cap1"); /* capability for object 1 */
	make_random_ideakey(a);
	make_random_ideakey(a+24); /* generate 48-bit random number */
	f = fopen(cap1, "w+");
	fwrite(a,1,6,f); /* server port - not examined */
	_buf_put_long(b,b+4,1);  /* object number 1 */
	fwrite(b,1,3,f); 
	fwrite(&y,1,1,f);  /* an owner capability - all rights bits set */
	fwrite(a,1,6,f); /* finally, our random number for the check field */
	fclose(f);

	strcpy(cap2,host);
	strcat(cap2,".cap2"); /* capability for object 2 */
	make_random_ideakey(a);
	make_random_ideakey(a+24);
	f = fopen(cap2, "w+");
	fwrite(a,1,6,f); 
	_buf_put_long(b,b+4,2);  /* object number 2 */
	fwrite(b,1,3,f);
	fwrite(&y,1,1,f);
	fwrite(a,1,6,f);
	fclose(f);

	strcpy(cap3,host);
	strcat(cap3,".cap3"); /* capability for object 3 */
	make_random_ideakey(a);
	make_random_ideakey(a+24);
	f = fopen(cap3, "w+");
	fwrite(a,1,6,f);
	_buf_put_long(b,b+4,3);  /* object number 3 */
	fwrite(b,1,3,f);
	fwrite(&y,1,1,f);
	fwrite(a,1,6,f);
	fclose(f);

	return 0;
}
