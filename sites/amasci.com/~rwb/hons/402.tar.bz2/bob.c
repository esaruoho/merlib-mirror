/* bob.c - the capability server */
/* Richard Bean, 13 November 1997 */

#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <netdb.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <errno.h>
#include "usuals.h"
#include "mpilib.h"
#include "idea.h"
#include "crypto.h"
#include "pgp.h"
#include "amoeba.h"
#include "rights.h"

FILE *pgpout=stderr; /* for pgp error messages, use standard error */

int log2(int num)
{
	/* this function returns the logarithm to base 2
	   of num, so that a request can be translated
	   into a string, e.g. 00000001 -> READ_FILE */

	int i,j=128;
	for (i=8; i; i--,j>>=1)
		if (num == j)
			return i-1;
}

rights_bits string2rights(char string[9])
{
	/* this function takes an 8-character string of 0s and 1s 
	   representing a binary number and translates it to an integer 
	   that could be used in a request */
	/* a call to strtol(string,NULL,2) would also work */
	rights_bits x=0;
	int i,j=128;
	for (i=8; i; i--,j>>=1)
		if (string[8-i] == '1')
			x += j;
	return x;
}

char *rights2string(rights_bits prights)
{
	/* this function takes an 8-bit number and
	   translates it to an 8-character string of
	   0s and 1s corresponding to the binary
	   representation of the number */
	/* no corresponding sprintf() call for this */ 

	char *string=(char *)calloc(9,1);
	int i,j=128;
	for (i=8; i; i--,j>>=1)
		string[8-i] = (!!(prights & j)) + '0';
	return string;
}
			
main(int argc, char **argv)
{
	/* the main function is a loop that takes requests from
	   clients.  before the infinite loop begins, a port
	   is set up and the port number is output for clients
	   to connect to.  the loop itself accepts connections
	   from clients and authenticates them, then reads
	   a capability, a request and some data, and acts
	   upon this information. */

	char *req[8] = {"READ_FILE","WRITE_FILE","READ_NAME","WRITE_NAME","READ_NAMEX","WRITE_NAMEX","ADD","REVOKE"}; /* for converting request numbers into strings */
        char localhost[100],remotehost[100],remotehostkey[100]; /* local host name, remote host name, remote host public key name */
	char cap1file[10],cap2file[10],cap3file[10],txtfile[10],namfile[10],filfile[10]; /* filenames */
	char s1[100],s2[100]; /* for reading pairs of entries from files */
	unsigned char request; /* the request from the client */ 
	FILE *hostkey,*f,*f2; /* various file pointers */
        int nlen,clilen,i,num; /* temporary or loop variables */
        struct hostent *hostptr; /* for gethostbyname() and gethostbyaddr() */
        byte pctb,timestamp; /* for readkeypacket() */
        unit na[MAX_UNIT_PRECISION], ea[MAX_UNIT_PRECISION],
        da[MAX_UNIT_PRECISION], pa[MAX_UNIT_PRECISION],
        qa[MAX_UNIT_PRECISION], ua[MAX_UNIT_PRECISION],
        nb[MAX_UNIT_PRECISION], eb[MAX_UNIT_PRECISION],
        db[MAX_UNIT_PRECISION], pb[MAX_UNIT_PRECISION],
        qb[MAX_UNIT_PRECISION], ub[MAX_UNIT_PRECISION]; /* for public and private key data for the server and the client */
        int s,newsockfd; /* socket */
        struct sockaddr_in serv_addr, cli_addr, new_addr; /* addresses */

        int status; /* return status from readkeypacket */
        byte k[24],a[24],b[24]; /* for random idea key and number in protocol */
        byte inbuf[MAX_BYTE_PRECISION], outbuf[MAX_BYTE_PRECISION]; /* encryption and decryption buffers */
        word16 iv0[4]; /* initialisation vector for IDEA */

	private priv;
	rights_bits prights;
	port check; /* these last three are for checking the validity of a capability */
	objnum obj; /* for extracting the object number from a capability */
	char objn[4] = {0,0,0,0}; /* for conversion purposes */

        if ((s=socket(AF_INET,SOCK_STREAM,0))<0) /* get a socket */
        { 
		printf("socket() failed\n");
		exit(0); 
	}
        bzero((char*)&serv_addr,sizeof(serv_addr));
        serv_addr.sin_family = AF_INET;
        serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
        serv_addr.sin_port = htons(0);

        if (bind(s,(struct sockaddr*)&serv_addr, sizeof(serv_addr)) <0) /* bind the socket */
        { 
		printf("bind() failed\n");
		exit(0); 
	}

        nlen = sizeof(serv_addr);
        if (getsockname(s, (struct sockaddr*)&serv_addr, &nlen)) /* get the socket's name */
        { 
		printf("getsockname() failed\n"); 
		exit(0); 
	}

        printf("port number is: %d\n", serv_addr.sin_port);
        listen(s,5); /* listen for connections - backlog of 5 connections */

        clilen = sizeof(cli_addr);
	while (1) 
	{ /* infinite connections loop */
        newsockfd = accept(s, (struct sockaddr *) &cli_addr, &clilen);
        if (newsockfd < 0)
        { 
		printf("accept() failed\n");
		exit(0); 
	}

	memset(inbuf,0,MAX_BYTE_PRECISION);
        num = read(newsockfd, inbuf, MAX_BYTE_PRECISION); /* user id and random number */
        if (num>0)
                /* printf("A and Ra received %d bytes\n",num); */ ;
        else
        {
                printf("wrong number of bytes received - exiting\n");
		close(newsockfd);
		continue;
        }
        /* printf("read %d bytes\n",num); */

        /* puts(inet_ntoa(cli_addr.sin_addr)); */
        hostptr = gethostbyaddr((char *)&(cli_addr.sin_addr.s_addr), sizeof(cli_addr.sin_addr), AF_INET);
	if (!hostptr) 
	{
		perror("gethostbyaddr()");
		close(newsockfd);
		continue;
	}

        /* printf("received from %d\n",hostptr); */
        strcpy(remotehostkey,hostptr->h_name);
        strcpy(remotehost,hostptr->h_name);
        strcat(remotehostkey,".pub"); /* the public key */

        /* get Alice's host name and her public key */
        hostkey=fopen(remotehostkey,"r");

        if (!hostkey)
        { 
        	printf("Error opening key file %s.  does file exist?\n",remotehost); 
		close(newsockfd);
		continue;
        }
        if ((status=readkeypacket(hostkey,0,&pctb,&timestamp,NULL, na,ea,NULL,NULL,NULL,NULL,NULL,NULL))<0)
        {
		printf("readkeypacket() failed for %s: status = %d\n",remotehost, status);
		close(newsockfd);
		continue;
        } 
        fclose(hostkey);

        /* get my own host name and the corresponding private key */
        gethostname(localhost,100);
        hostkey=fopen(localhost,"r");
        if (!hostkey)
        { 
        	printf("Error opening key file %s.  does file exist?\n",localhost); 
		close(newsockfd);
		continue;
        }
        if ((status=readkeypacket(hostkey,0,&pctb,&timestamp,NULL, nb,eb,db,pb,qb,ub,NULL,NULL))<0)
        {
		printf("readkeypacket() failed for %s: status = %d\n",localhost,status);
		close(newsockfd);
		continue;
        } 
        fclose(hostkey);
	
        /* decrypt received data with Bob's private key */
	memset(outbuf,0,MAX_BYTE_PRECISION);
        num=rsa_private_decrypt(outbuf, (unitptr)inbuf, eb, db, pb, qb, ub, nb);
        /* printf("number of bytes extracted: %d\n",num); */
        if (num < 0) 
	{
		printf("error in rsa_private_decrypt(): %d\n",num);
		close(newsockfd);
		continue;
	}
        /*
        printf("A received is: %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X \n",outbuf[0],outbuf[1],outbuf[2],outbuf[3],outbuf[4],outbuf[5],outbuf[6],outbuf[7],outbuf[8],outbuf[9],outbuf[10],outbuf[11],outbuf[12],outbuf[13],outbuf[14],outbuf[15]);
        printf("Ra received is: ");
        for (i = 0; i<16; i++)
                printf("%02X ", outbuf[16+i]);
        printf("\n"); 
	*/
        memcpy(a,outbuf+16,16); /* copy received Ra */

        make_random_ideakey(b); /* the random number Rb */
        make_random_ideakey(k); /* session key Ks */

        memset(inbuf,0,MAX_BYTE_PRECISION);
        memcpy(inbuf,a,16); /* the first random number Ra, sent back */

        memcpy(inbuf+16,b,16); /* 128-bit random number */
        /*
        printf("Rb sent is: ");
        for (i = 0; i<16; i++)
                printf("%02X ", inbuf[16+i]);
        printf("\n");
        */      
        memcpy(inbuf+32,k,16); /* session key */
        /*
        printf("Ks sent is: ");
        for (i = 0; i<16; i++)
                printf("%02X ", inbuf[32+i]);
        printf("\n");
        */
        /* encrypt with Alice's public key */

        memset(outbuf,0,MAX_BYTE_PRECISION);

	/*
        printf("encrypting this data: ");
        for (i = 0; i<MAX_BYTE_PRECISION; i++)
                printf("%02X ", inbuf[i]);
        printf("\n"); */

        num=rsa_public_encrypt((unitptr)outbuf, inbuf, 3*IDEAKEYSIZE, ea, na);
	if (num<0){printf("rsa_public_encrypt() failed: returns %d\n",num);}

        /* mp_display("bob (outbuf) =",outbuf); */

        
        write(newsockfd,outbuf,MAX_BYTE_PRECISION); /* send it */

        memset(outbuf,0,MAX_BYTE_PRECISION);

        num=read(newsockfd,outbuf,IDEAKEYSIZE);
        if (num>0)
                /* printf("Ks(Rb) received\n"); */ ;
        else
        {
                printf("wrong size for Ks(Rb) - exiting\n");
		close(newsockfd);
		continue;
        }
        /* printf("read %d bytes\n",num); */

        memset(iv0,0,8); /* clear initialisation vector */
        initcfb_idea(iv0, k, 1);  /* decryption mode */
        ideacfb(outbuf,IDEAKEYSIZE);
        
        /* printf("Rb received is: ");
        for (i = 0; i<16; i++)
                printf("%02X ", outbuf[i]);
        printf("\n"); */
        if (!strncmp(outbuf, b, IDEAKEYSIZE))
        {
                /* printf("Rb received == original Rb sent\n");
                printf("Authentication succeeded\n"); */
        }
        else
        {
                printf("Rb received != original Rb sent\n");
                printf("Authentication failed\n");
		close(newsockfd);
		continue;
        }

	/* now receive a capability */

	num = read(newsockfd,inbuf,16); /* 128-bit capability standard in Amoeba */
	if (num == 16)
	{
		/*	
		printf("capability received\n");
		for (i=0; i<16; i++)
			printf("%02x ",inbuf[i]);
		printf("\n");
		*/	
	}
	else
	{
		printf("capability received has wrong size\n");
		close(newsockfd);
		continue;
	}

	/* and decrypt it with the shared session key */
	memset(iv0,0,8); /* clear initialisation vector */
	initcfb_idea(iv0, k, 1); /* decryption mode again */
	ideacfb(inbuf,16);
        close_idea();
		/* printf("capability decrypted\n");
		for (i=0; i<16; i++)
			printf("%02x ",inbuf[i]);
		printf("\n"); */

	memset(cap1file,0,10);
	memset(cap2file,0,10);
	memset(cap3file,0,10);
	memset(txtfile,0,10);
	memset(namfile,0,10);
	memset(filfile,0,10); /* clear away previous requests */
	strncpy(cap1file,localhost,3);
	strncpy(cap2file,localhost,3);
	strncpy(cap3file,localhost,3);
	strcat(cap1file,".cap1"); /* owner capability for object 1 */
	strcat(cap2file,".cap2"); /* owner capability for object 2 */
	strcat(cap3file,".cap3"); /* owner capability for object 3 */
	strncpy(objn, inbuf+6, 3);
	_buf_get_long(objn,objn+4,&obj); /* get obj number */

	/* get original check field from owner capability */
	if (obj == 1) /* file server */
	{
		f=fopen(cap1file,"r");
		if (!f) 
		{
			printf("error opening %s\n",cap1file);
			close(newsockfd);
			continue;
		}
		fseek(f,10,SEEK_SET);
		fread(&check,1,6,f); /* read 48-bit check field */
		fclose(f);
	}
	else if (obj == 2) /* name server */
	{
		f=fopen(cap2file,"r");
		if (!f) 
		{
			printf("error opening %s\n",cap2file);
			close(newsockfd);
			continue;
		}
		fseek(f,10,SEEK_SET);
		fread(&check,1,6,f); 
		fclose(f);
	}
	else if (obj == 3) /* trust list */
	{
		f=fopen(cap3file,"r");
		if (!f) 
		{
			printf("error opening %s\n",cap3file);
			close(newsockfd);
			continue;
		}
		fseek(f,10,SEEK_SET);
		fread(&check,1,6,f); 
		fclose(f);
	}

	/* get request type */
	num=read(newsockfd, &request, 1); 
	if (num != 1)
	{
		printf("error reading request: read() returns %d\n",num);
		perror("read error");
		close(newsockfd);
		continue;
	}

	strncpy(txtfile,localhost,3);
	strcat(txtfile,".txt"); /* list of trusted hosts, and rights */

	strncpy(filfile,localhost,3);
	strcat(filfile,".fil"); /* text file for reading & writing */

	strncpy(namfile,localhost,3);
	strcat(namfile,".nam"); /* name server file for reading */
	
	memcpy(priv.prv_object, inbuf+6, 3); /* same order of bytes */
	priv.prv_rights=inbuf[9]; 
	memcpy(&(priv.prv_random), inbuf+10, 6);

	/* printf("priv.prv_rights = %02x\n",priv.prv_rights); 
	
	for (i=0; i<16; i++)
		printf("%02x ", inbuf[i]);
	printf("\n"); */

	/* check the validity of the capability */
	if (_prv_decode(&priv, &prights, &check) != 0)
	{
		printf("bad capability presented\n"); 
		close(newsockfd);
		continue;
	}
	/* printf("prights = %02x\n",prights); */
	/* now go through the trust file for this server and fix
	   the rights bits up - since other objects may have told the
	   server to trust this object */
	f = fopen(txtfile,"r");	
	if (!f) 
	{
		printf("trust file not found\n");
		continue;
	}
	while(1)
	{
		fscanf(f,"%s %s",s1,s2);
		if (feof(f)) break;
		if (!strncmp(s1, remotehost, strlen(remotehost)))
		{
			rights_bits pr = string2rights(s2);
			prights |= pr; /* add all bits possible */
		}		
	}
	fclose(f);

	if (obj == 1) /* object is a file */
	{
		char data[40];
		memset(data,0,40);
		num = read(newsockfd, data, 40); /* get what to write */
		if (request == WRITE_FILE && (prights & WRITE_FILE)) 
		{
			f = fopen(filfile, "w");
			if (!f)
			{
				printf("fopen() of filfile %s failed\n",filfile);
			}
			fwrite(data, 1,  num, f);
			fclose(f);
			printf("WRITE_FILE request successful, %d bytes written\n",num);
			close(newsockfd);
			continue;
		}
		else if (request == READ_FILE && (prights & READ_FILE)) 
		{
			/* data array is the number of bytes to read here */
			int num = atoi(data);
			memset(data,0,40);
			f = fopen(filfile,"r");
			if (!f)
			{
				printf("fopen() of filfile %s failed\n",filfile);
			}
			fread(data, 1, num, f);
			fclose(f);
			printf("%s\n",data);
			printf("READ_FILE request successful, %d bytes read\n",num);
			close(newsockfd);
			continue;
		}
		else
		{
			printf("File object failure: request = %s, prights = %s\n",req[log2(request)], rights2string(prights));
			close(newsockfd);
			continue;
		}
	}
	else if (obj == 2) /* the object is a name server */
	{
		char request2[40];
		memset(request2,0,40);
		num = read(newsockfd, request2, 40); /* get host name */
		if (request == WRITE_NAME && (prights & WRITE_NAME)) 
		{
			printf("WRITE_NAME unimplemented\n");
			close(newsockfd); /* unimplemented */
			continue;
		}
		else if (request == READ_NAME && (prights & READ_NAME)) 
		{
			char s[100];
			if (!strstr(request2,"pselab.uq.edu.au")) /* not protected name space */
			{
				f = fopen(namfile,"r");
				if (!f)
				{
					printf("can't open namefile %s\n",namfile);
					close(newsockfd);
					continue;
				}
				while (1)
				{
					fscanf(f,"%s %s",s1,s2);
					/* printf("%s %s\n",s1,s2);
					printf("s1 = %s strlen(request2) = %d request2 = %s\n",s1,strlen(request2),request2); */
					if (feof(f)) break;
					if (!strncmp(s1, request2, strlen(request2)))
						printf("%s %s\n",s1,s2);
				}
				fclose(f);
				printf("READ_NAME request successful\n");
				close(newsockfd);
				continue;
			}
			else
			{
				printf("invalid name resolve request - can't access protected name space\n");
				close(newsockfd);
				continue;
			}
		}
		else if (request == WRITE_NAMEX && (prights & WRITE_NAMEX)) 
		{
			printf("WRITE_NAMEX unimplemented\n");
			close(newsockfd); /* unimplemented */
			continue;
		}
		else if (request == READ_NAMEX && (prights & READ_NAMEX)) 
		{
			char s[100];
			memset(s,0,100);
			hostptr=gethostbyname(request2);
			f = fopen(namfile,"r");
			if (!f)
			{
				printf("can't open namefile %s\n",namfile);
				close(newsockfd);
				continue;
			}
			while(1)
			{
				fscanf(f,"%s %s",s1,s2);
				if (feof(f)) break;
				/* printf("** %s %s\n",s1,s2);
				printf("** s1 = %s strlen(request2) = %d request2 = %s\n",s1,strlen(request2),request2); */
				if (!strncmp(s1, request2, strlen(request2)))
					printf("%s %s\n",s1,s2);
			}
			fclose(f);
			printf("READ_NAMEX request successful\n");
			close(newsockfd);
			continue;
		}
		else
		{
			printf("Name object failure: request = %s, prights = %s\n",req[log2(request)], rights2string(prights));
			close(newsockfd);
			continue;
		}
	}
	else if (obj == 3) /* the object is a trust list */
	{
		char request2[40];
		memset(request2,0,40);
		num = read(newsockfd,request2,40); /* get host name and rights bits */
		if (request == ADD)
		{	
			f = fopen(txtfile, "a");
			if (!f)
			{
				printf("can't open txtfile %s\n",txtfile);
				close(newsockfd);
				continue;
			}
			fprintf(f,"%s\n",request2);
			fclose(f);
			printf("ADD request successful\n");
			close(newsockfd);
			continue;
		}
		else if (request == REVOKE)
		{
			FILE *f2;
			char tmpfile[100];
			strcat(request2,"\n"); /* fgets adds a '\n' */
			strcpy(tmpfile,txtfile);
			strcat(tmpfile,".tmp");
			f = fopen(txtfile, "r");
			if (!f)
			{
				printf("can't open txtfile %s\n",txtfile);
				close(newsockfd);
				continue;
			}
			f2 = fopen(tmpfile, "w");
			if (!f2)
			{
				printf("can't open tmpfile %s\n",tmpfile);
				close(newsockfd);
				continue;
			}
			while (1)
			{	
				fgets(s1,100,f);
				if (feof(f)) break;
				if (strcmp(s1, request2)) /* delete host */
					fprintf(f2,s1);
			}
			fclose(f);
			fclose(f2);
			rename(tmpfile,txtfile);
			printf("REVOKE request successful\n");
			close(newsockfd);
			continue;
		}
		else 
		{
			printf("Trust list object failure: request = %s, prights = %s\n",req[log2(request)], rights2string(prights));
			close(newsockfd);
			continue;
		}
	}
	close(newsockfd);
	}
        return 0;
}
