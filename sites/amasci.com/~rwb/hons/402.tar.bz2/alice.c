/* alice.c - the client for the capability server */
/* Richard Bean, 13 November 1997 */

#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <netdb.h>
#include <sys/socket.h>
#include "usuals.h"
#include "mpilib.h"
#include "idea.h"
#include "crypto.h"
#include "pgp.h"
#include "amoeba.h"
#include "rights.h"
FILE *pgpout=stderr;

main(int argc, char **argv)
{
	/* this program connects to the server, authenticates the
	   server while authenticating itself to the client,
	   and then sends the capability given on the command line
	   plus the request and request data */

        char localhost[100],remotehost[100],remotehostkey[100]; /* filenames for the private and public keys */
	
	byte cap[16]; /* capability, type byte because requires IDEA encrypt*/
        FILE *hostkey,*f; /* file pointers */
        int num; /* loop variables and temporary variables */
        struct hostent *hostptr; /* for gethostbyname() */
        byte pctb,timestamp; /* for readkeypacket() */
        unit na[MAX_UNIT_PRECISION], ea[MAX_UNIT_PRECISION],
        da[MAX_UNIT_PRECISION], pa[MAX_UNIT_PRECISION],
        qa[MAX_UNIT_PRECISION], ua[MAX_UNIT_PRECISION],
        nb[MAX_UNIT_PRECISION], eb[MAX_UNIT_PRECISION],
        db[MAX_UNIT_PRECISION], pb[MAX_UNIT_PRECISION],
        qb[MAX_UNIT_PRECISION], ub[MAX_UNIT_PRECISION]; /* to store the public and private keys for the server and client */
        int s; /* socket */
        struct sockaddr_in new_addr; /* for connect() */
	unsigned char request; /* for sending the request */
	char *capfile; /* argv[3] alias for capability file */
	char *reqtype; /* argv[4] alias for request type */
	char *requestdata; /* argv[5] alias for request */
	objnum obj; /* request helps us decide which obj num to use */

        int status; /* return status from readkeypacket */
        byte a[24],b[24],k[24]; /* for random idea key and number in protocol */
        byte inbuf[MAX_BYTE_PRECISION],outbuf[MAX_BYTE_PRECISION]; /* encryption/decryption buffers */
        word16 iv0[4]; /* initialisation vector for IDEA */

        if (argc != 6)  /* right number of arguments? */
	{
		printf("usage: client <host> <port> <cap> <reqtype> <req>\n");
		exit(0);
	}

        /* get the host name and the corresponding public key */
        strcpy(remotehost,argv[1]);
        strcpy(remotehostkey,argv[1]);
        strcat(remotehostkey,".pub");

        hostkey=fopen(remotehostkey,"r");
        
        if (!hostkey)
        { 
		printf("Error opening key file %s.  does file exist?\n",remotehost); 
		exit(0);
        }
        if ((status=readkeypacket(hostkey,0,&pctb,&timestamp,NULL, nb,eb,NULL,NULL,NULL,NULL,NULL,NULL))<0)
        {
                        printf("readkeypacket() failed for %s: status = %d\n",remotehost,status);
                        exit(0);
        } 
        fclose(hostkey);

        /* get Alice's hostname and her private key */
        gethostname(localhost,100); 
        hostkey=fopen(localhost,"r");
        if (!hostkey)
        { 
		printf("Error opening key file %s.  does file exist?\n",localhost); 
		exit(0);
        }
        if ((status=readkeypacket(hostkey,0,&pctb,&timestamp,NULL, na,ea,da,pa,qa,ua,NULL,NULL))<0)
        {
                        printf("readkeypacket() failed for %s: status = %d\n",localhost,status);
                        exit(0);
        } 
        fclose(hostkey);

        make_random_ideakey(a); /* the random number Ra */
        s=socket(PF_INET,SOCK_STREAM,0);
        if ((hostptr = gethostbyname(argv[1])) == NULL) 
        { 
		printf("gethostbyname() failed\n");
		exit(0);
	}

        bzero((char*)&new_addr,sizeof(new_addr));
        new_addr.sin_family=AF_INET;
        new_addr.sin_addr.s_addr = ((struct in_addr *)*(hostptr -> h_addr_list))->s_addr;
        new_addr.sin_port = htons(atoi(argv[2]));

        if(connect(s,(struct sockaddr *)&new_addr,sizeof(new_addr))<0)
        {
		printf("can't connect to server\n");
		exit(0);
	}

        memset(inbuf,0,MAX_BYTE_PRECISION);
        memset(outbuf,0,MAX_BYTE_PRECISION);
        memcpy(inbuf+16,a,16); /* 128-bit random number */

	/* The idea was to add the Ethernet address or the IP address +
	   port into the first 48 bits of what is sent to the server.
	   Unfortunately getting the Ethernet address  this requires
	   that "/dev/le" be read, and this is not possible without
	   root access.  A system() call to "arp -a" would be possible,
	   but this is effectively the same method that is being used
	   at the client:  a call to ioctl(), but everyone can read the
	   ARP tables.  Using the IP address + port doesn't accomplish
	   anything as the server doesn't know the client's identity
	   beforehand.  So, the identity field remains unused here. */

        /* encrypt with Bob's public key */

        num = rsa_public_encrypt((unitptr)outbuf, inbuf, 32, eb, nb);
        if (num<0) 
	{
		printf("error encrypting with Bob's PK %d\n",num);
		exit(0);
	}

        write(s,outbuf,MAX_BYTE_PRECISION); /* send it */

        memset(inbuf,0,MAX_BYTE_PRECISION);
        num=read(s, inbuf, MAX_BYTE_PRECISION); /* read Ra, Rb, and Ks */
        if (num>0)
                /* printf("Ea(Ra, Rb, Ks) received\n"); */ ;
        else
        {
                printf("Ea(Ra, Rb, Ks) - wrong size - exiting\n");
                exit(0);
        }

        memset(outbuf,0,MAX_BYTE_PRECISION);

	/* decrypt with client's private key */
        num=rsa_private_decrypt(outbuf, (unitptr)inbuf, ea,da,pa,qa,ua,na);
        
        if (num < 0) 
        {
                printf("error in rsa_private_decrypt():returns %d\n",num);
                exit(-1);
        }

        if (!strncmp(outbuf,a,IDEAKEYSIZE))
        {
		/* no output if authentication succeeds */
                /* printf("Ra received == original Ra sent\n");
                printf("Authentication succeeded\n"); */
        }
        else
        {
                printf("Ra received != original Ra sent\n");
                printf("Authentication failed\n");
        }

        memcpy(k,outbuf+32,IDEAKEYSIZE);

        /* encrypt */
        memset(iv0,0,8);
        initcfb_idea(iv0, k, 0); 
        memcpy(b, outbuf+16, IDEAKEYSIZE);
        memset(outbuf, 0, MAX_BYTE_PRECISION);

        /* Use IDEA to encrypt Rb */
        ideacfb(b,IDEAKEYSIZE);

        write(s,b,16);

        /* decrypt */
        /* memset(iv0,0,8);
        initcfb_idea(iv0, k, 1); */
        /*ideacfb(buffer,sizeof(buffer));*/
        
        /*close_idea();*/

	/* now send the encrypted capability */

	/* decide what kind of object the client wants! */

	reqtype = argv[4];
	if (!strcmp(reqtype, "READ_FILE")) /* file object */
	{
		request = READ_FILE;
		obj = 1;
	} 
	else if (!strcmp(reqtype,"WRITE_FILE"))
	{
		request = WRITE_FILE;
		obj = 1;
	}
	else if (!strcmp(reqtype,"READ_NAME"))
	{
		request = READ_NAME; 
		obj = 2;
	} 
	else if (!strcmp(reqtype,"WRITE_NAME")) /* name server object */
	{
		request = WRITE_NAME; 
		obj = 2;
	}
	else if (!strcmp(reqtype,"READ_NAMEX"))
	{
		request = READ_NAMEX; 
		obj = 2;
	}
	else if (!strcmp(reqtype,"WRITE_NAMEX"))
	{
		request = WRITE_NAMEX; 
		obj = 2;
	}
	else if (!strcmp(reqtype, "ADD")) /* trust list object */
	{
		request = ADD; 
		obj = 3;
	}
	else if (!strcmp(reqtype, "REVOKE"))
	{
		request = REVOKE; 
		obj = 3;
	}

	capfile = argv[3];
	/* get the capability from the file */
	f = fopen(capfile, "r");
	if (!f) 
	{
		printf("error opening %s\n",capfile);
		exit(1);
	}
	fread(cap, 1, 16, f);
	
	fclose(f);

	/* encrypt the capability */ 
	memset(iv0,0,8); /* clear initialisation vector */
	initcfb_idea(iv0, k, 0);

	/* for (i=0; i<16; i++)
		printf("%02x ",cap[i]);
	printf("\n"); */

	ideacfb(cap,16);
	close_idea();

	/* send the capability - only the capability is encrypted */
	/* for (i=0; i<16; i++)
		printf("%02x ",cap[i]);
	printf("\n"); */
	num = write(s, cap, 16);

	/* send the request type */
	num = write(s,&request, 1);
	/* printf("sending request %d\n",request); */

	/* send the request */
	requestdata = argv[5];
	num = write(s, requestdata, strlen(requestdata));
	
        return 0;
}
