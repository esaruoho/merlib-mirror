/* rights.h - the rights for the capability server simulation */
/* Richard Bean, 13 November 1997 */

#define READ_FILE 	0x01	/* right to read a file */
#define WRITE_FILE	0x02	/* right to write to a file */
#define READ_NAME	0x04	/* right to resolve a name */
#define WRITE_NAME	0x08	/* right to add a name to list */
#define READ_NAMEX	0x10	/* right to resolve a protected name */
#define WRITE_NAMEX	0x20	/* right to add a protected name to list */
#define ADD		0x40	/* right to add an object id to trust list */
#define REVOKE		0x80	/* right to revoke an id from a trust list */

/* The standard rights for Amoeba.  The capability server being
   simulated has more rights bits as it shows the problems with
   presenting the right capability to the wrong object, or
   the wrong capability to the right object.  
*/

/*	@(#)stdrights.h	1.2	94/04/06 15:52:09 */
/*
 * Copyright 1994 Vrije Universiteit and Stichting Mathematisch Centrum,
 * The Netherlands.
 * For full copyright and restrictions on use see the file COPYRIGHT in
 * the top level of the Amoeba distribution.
 */

#ifndef __STDRIGHTS_H__
#define __STDRIGHTS_H__

/* Rights: */
#define RGT_CREATE	0x01
#define RGT_READ	0x02
#define RGT_MODIFY	0x04
#define RGT_DELETE	0x08

#endif /* __STDRIGHTS_H__ */
