#include <math.h>
#include <sys/time.h>
#include <stdlib.h>
#include <stdio.h>
#define SIZE 5

int             s[SIZE][SIZE], u[SIZE][SIZE];
int n=SIZE;
/* 211 */ int s1[5][5]={{1,2,3,4,5},{2,1,4,5,3},{3,5,1,2,4},{4,3,5,1,2},{5,4,2,3,1}}; 
long count = 0;

int
testone(int a, int b)
{
	int             t[25];
	int             that;
	int             i;
	int             goodflag = 0;
	for (i = 1; i <= n; i++)
		t[i] = 0;
	for (i = 0; i < n; i++)
		t[s[a][i]] = t[s[i][b]] = 1; /* set both to 1 */
	for (i = 1; i <= n; i++)
		if (t[i])
			goodflag++;
		else
			that = i;
	if (goodflag == n - 1)
	{
		s[a][b] = that;
		return 1;
	}
	else
		return 0;
}

void
print()
{
	int             a, b;
	for (a = 0; a < n; a++) 
	{
		for (b = 0; b < n; b++) 
		{
			printf("%d", u[a][b]);
		} 
		printf(" ");
	} 
	printf("\n");
	/******************
	for (a = 0; a < n; a++) 
	{
		for (b = 0; b < n; b++) 
		{
			printf("%d", s[a][b]);
		} 
		printf(" ");
	} 
	printf("\n");
	printf("\n");
	******************/
}

fill()
{
		int a,b,changed,mod=1,flag=0;

		while (mod) {
			/* go through each element in the latin square */
			/* and test whether that element has a forced */
			/* completion. */
			mod = 0;
			for (a = 0; a < n; a++) {
				for (b = 0; b < n; b++) {
					if (!s[a][b])
					{
						changed=testone(a, b);
						flag += changed;
						if (!mod && changed)
							mod = 1;
					}
			}
		}
	}
	return (flag==n*n-6);
}

int
main()
{
	int             a, b;
	int j0,j1,j2,j3,j4,j5,j6,j7,j8,j9,j10,x0,x1,x2,x3,x4,x5,x6,x7,x8,x9,x10,y0,y1,y2,y3,y4,y5,y6,y7,y8,y9,y10;

	for (j0 = 0; j0 <= 19; j0++)
	for (j1 = j0+1; j1 <= 20; j1++)
	for (j2 = j1+1; j2 <= 21; j2++)
	for (j3 = j2+1; j3 <= 22; j3++)
	for (j4 = j3+1; j4 <= 23; j4++)
	for (j5 = j4+1; j5 <= 24; j5++){

		count ++ ;
		if (count % 1000000 == 0) printf("count = %d\n",count);
		/* fill the latin square with zeros */

		for (a = 0; a < n; a++) {
			for (b = 0; b < n; b++) {
				s[a][b] = u[a][b] = 0;
			}
		}

		/* put the relevant entries in */	

		x0  = j0%SIZE;  y0  = j0/SIZE;
		x1  = j1%SIZE;  y1  = j1/SIZE;
		x2  = j2%SIZE;  y2  = j2/SIZE;
		x3  = j3%SIZE;  y3  = j3/SIZE;
		x4  = j4%SIZE;  y4  = j4/SIZE;
		x5  = j5%SIZE;  y5  = j5/SIZE;

		u[y0][x0]=s[y0][x0]=s1[y0][x0];
		u[y1][x1]=s[y1][x1]=s1[y1][x1];
		u[y2][x2]=s[y2][x2]=s1[y2][x2];
		u[y3][x3]=s[y3][x3]=s1[y3][x3];
		u[y4][x4]=s[y4][x4]=s1[y4][x4];
		u[y5][x5]=s[y5][x5]=s1[y5][x5];

			/*
		 	 * go through the latin square to guess 
			 * the values of certain squares
		 	 */

			if (fill()) print();
		}
}
