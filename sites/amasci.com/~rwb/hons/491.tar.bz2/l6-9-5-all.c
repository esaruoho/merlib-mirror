#include <stdio.h>
#define SIZE 6
#define CRITSIZE 9

struct bitmap
{
	int count;
	int values[SIZE+1];
};
long count = 0;

struct bitmap
testone(int s[SIZE][SIZE], int a, int b)
{
	struct bitmap bm;
	int             t[SIZE+1];
	int             that;
	int             i;
	for (i = 1; i <= SIZE; i++)
	{
		t[i] = 0;
		bm.values[i] = 0;
	}
	bm.count = 0;
	for (i = 0; i < SIZE; i++)
		t[s[a][i]] = t[s[i][b]] = 1;
	for (i = 1; i <= SIZE; i++)
		if (!t[i])
		{
			bm.values[i] = 1;
			that = i;
			bm.count ++;
		}
	/* if (bm.count == 1)
		s[a][b] = that; */
	return bm;
}

void
print(int s[SIZE][SIZE])
{
	int             x, y;
	for (y = 0; y < SIZE; y++) 
	{
		for (x = 0; x < SIZE; x++) 
		{
			printf("%d", s[y][x]);
		} 
		printf(" ");
	} 
	printf("\n");
}

int fill(int s[SIZE][SIZE], int level, int pos)
{
	/* for this function, we are assuming that at 
	   some point the function will return 1 for
	   a forced latin square */
	/* also: during forcing: if no element could
	   possibly *be* in a position, then there
	   is no point in continuing. */
	int a,b,c,flag = 0, poss = 0, mod=1;
	struct bitmap ret;
	if (level == SIZE * SIZE - CRITSIZE) 
		return 1;

	/* now try all possibilities */
		a = pos % SIZE; b = pos / SIZE;
		while ( b*SIZE + a < SIZE * SIZE)
		{
			if (!s[a][b])
			{
				ret = testone(s,a,b);
				if (ret.count == 0) return 0;
				for (c = 1; c <= SIZE; c++)
				{	
					if (ret.values[c])
					{
						s[a][b] = c;
						poss += fill(s, level+1, b*SIZE + a+ 1);
						s[a][b] = 0;
					}
					/* return immediately if > 1 */
					if (poss>1) return poss;
				}
				/* if one square fails,
				   forget about the rest */
				if (poss == 0) return 0;
			}			
			a++; if (a==SIZE) {b++; a=0;}
		}
	return poss;
}

int
main(int argc, char **argv)
{
	int             s[SIZE][SIZE], u[SIZE][SIZE];
	int             a, b; 
	int j[CRITSIZE],x[CRITSIZE],y[CRITSIZE];
	int s1[6][6]={{1,2,3,4,5,6},{2,1,4,3,6,5},{3,4,5,6,1,2},{4,3,6,5,2,1},{5,6,2,1,4,3},{6,5,1,2,3,4}};

	for (j[8] = 0       ; j[8] <= SIZE * SIZE - 9; j[8]++)
	for (j[7] = j[8] + 1; j[7] <= SIZE * SIZE - 8; j[7]++)
	for (j[6] = j[7] + 1; j[6] <= SIZE * SIZE - 7; j[6]++)
	for (j[5] = j[6] + 1; j[5] <= SIZE * SIZE - 6; j[5]++)
	for (j[4] = j[5] + 1; j[4] <= SIZE * SIZE - 5; j[4]++)
	for (j[3] = j[4] + 1; j[3] <= SIZE * SIZE - 4; j[3]++)
	for (j[2] = j[3] + 1; j[2] <= SIZE * SIZE - 3; j[2]++)
	for (j[1] = j[2] + 1; j[1] <= SIZE * SIZE - 2; j[1]++)
	for (j[0] = j[1] + 1; j[0] <= SIZE * SIZE - 1; j[0]++)
	{
		/* fill the latin square with zeros */
		count++;
		if (count % 1000000 == 0) 
		{
			printf("count = %d\n",count);
			fflush(stdout);
		}
		for (a = 0; a < SIZE; a++) {
			for (b = 0; b < SIZE; b++) {
				s[a][b] = u[a][b] = 0;
			}
		}

		/* put the relevant entries in */	

		for (a = 0; a < CRITSIZE; a++)
		{
			x[a] = j[a] % SIZE; y[a] = j[a] / SIZE;
			u[y[a]][x[a]] = s[y[a]][x[a]] = s1[y[a]][x[a]];
		}
	         /*
		 * go through the latin square to guess 
	         * the values of certain squares
		 */

		/* if there is one unique completion
		   then print out the value */
		if(fill(s,0,0)==1) print(u);
		}
}
