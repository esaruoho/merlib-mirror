#include <math.h>
#include <sys/time.h>
#include <stdlib.h>
#include <stdio.h>

int             s[25][25], u[25][25];
int             n,fin;
int             changed;
/* not the back-circulant square */
int s1[6][6]={{1,2,3,4,5,6},{2,1,4,3,6,5},{3,4,5,6,1,2},{4,3,6,5,2,1},{5,6,1,2,4,3},{6,5,2,1,3,4}};

void            print();

int
testsquare()
{
	int             a, b, c;
	int             test[50];
	/* test if it is a latin square */

	/*
	 * how many times does each number occur in each column?
	 */

	/* initialise the array */

	for (a = 0; a <= n; a++)
		test[a] = 0;

	for (a = 1; a <= n; a++) {
		for (b = 0; b < n; b++) {
			for (c = 0; c < n; c++) {
				if (s[b][c] == a)
					test[c]++;
			}
		}
		for (b = 1; b < n; b++)
			if (test[b] > 1) {
				/*
				 * printf("the number %d occurs in column %d
				 * %d times\n", a, b+1, test[b]);
				 */
				/* print(); */
				return 0;
			}
		for (b = 0; b <= n; b++)
			test[b] = 0;
	}

	/*
	 * how many times does each number occur in each row?
	 */

	/* initialise the array */

	for (a = 0; a < n; a++)
		test[a] = 0;

	for (a = 1; a < n; a++) {
		for (b = 0; b < n; b++) {
			for (c = 0; c < n; c++) {
				if (s[b][c] == a)
					test[b]++;
			}
		}
		for (b = 1; b < n; b++)
			if (test[b] > 1) {
				/*
				 * printf("the number %d occurs in row %d %d
				 * times\n", a, b+1, test[b]);
				 */
				/* print(); */
				return 0;
			}
		for (b = 0; b <= n; b++)
			test[b] = 0;
	}
	return 1;
}

int
testone(int a, int b)
{
	int             t[25];
	int             that;
	int             i;
	int             goodflag = 0;
	for (i = 0; i < 25; i++)
		t[i] = 0;
	for (i = 0; i < n; i++)
		t[s[a][i]] = t[s[i][b]] = 1;
	for (i = 1; i <= n; i++)
		if (t[i])
			goodflag++;
		else
			that = i;
	if (goodflag == n - 1)
		changed = s[a][b] = that;
}

void
print()
{
	int             a, b;
	for (a = 0; a < n; a++) 
	{
		for (b = 0; b < n; b++) 
		{
			printf("%d", u[a][b]);
		} 
		printf(" ");
	} 
	printf("\n");
}

fill()
{
		int a,b,flag = 1;
		while (flag) {
			/* go through each element in the latin square */
			/* and test whether that element has a forced */
			/* completion. */
			for (a = 0; a < n; a++) {
				for (b = 0; b < n; b++) {
					changed = 0;
					if (!s[a][b])
						testone(a, b);
					if (changed)
						break;
			}
			if (changed)
				break;
		}

		/* assume latin square is finished... */
		fin = 1;
		for (a = 0; a < n; a++) {
			for (b = 0; b < n; b++) {
				if (s[a][b] == 0)
					fin = 0;
			}
		}

		/* if it is finished, test if it is valid */
		if (fin) {
			fin = testsquare();
		}

		if (fin) {
			flag = 0;
			break;
		}

		/* if it did not change, break out */
		if (!changed) {
			flag = 0;
			break;
		}

		if (changed)
			changed = 0;
		}
}

int
main(int argc, char **argv)
{
	int             a, b, c, d;
	int j0,j1,j2,j3,j4,j5,j6,j7,j8,x0,x1,x2,x3,x4,x5,x6,x7,x8,y0,y1,y2,y3,y4,y5,y6,y7,y8;
	int             test[25];
	long            count = 0;
	int             flag;
	int             hugeflag = 1;
	long p2 = 1;
	struct timeval  tp;
	struct timezone tzp;
	double lc, l2, ld;
	tzp.tz_minuteswest = 0;
	tzp.tz_dsttime = 0;
	n = 6; 

	for (j0 = 0; j0 <= 27; j0++)
	for (j1 = j0+1; j1 <= 28; j1++)
	for (j2 = j1+1; j2 <= 29; j2++)
	for (j3 = j2+1; j3 <= 30; j3++)
	for (j4 = j3+1; j4 <= 31; j4++)
	for (j5 = j4+1; j5 <= 32; j5++)
	for (j6 = j5+1; j6 <= 33; j6++)
	for (j7 = j6+1; j7 <= 34; j7++)
	for (j8 = j7+1; j8 <= 35; j8++){

		count ++ ;
		if (count % 1000000 == 0) printf("count = %d\n",count);
		/* fill the latin square with zeros */

		for (a = 0; a < n; a++) {
			for (b = 0; b < n; b++) {
				s[a][b] = u[a][b] = 0;
			}
		}

		/* put the relevant entries in */	

		x0 = j0%6; y0 = j0/6;
		x1 = j1%6; y1 = j1/6;
		x2 = j2%6; y2 = j2/6;
		x3 = j3%6; y3 = j3/6;
		x4 = j4%6; y4 = j4/6;
		x5 = j5%6; y5 = j5/6;
		x6 = j6%6; y6 = j6/6;
		x7 = j7%6; y7 = j7/6;
		x8 = j8%6; y8 = j8/6;

		u[y0][x0]=s[y0][x0]=s1[y0][x0];
		u[y1][x1]=s[y1][x1]=s1[y1][x1];
		u[y2][x2]=s[y2][x2]=s1[y2][x2];
		u[y3][x3]=s[y3][x3]=s1[y3][x3];
		u[y4][x4]=s[y4][x4]=s1[y4][x4];
		u[y5][x5]=s[y5][x5]=s1[y5][x5];
		u[y6][x6]=s[y6][x6]=s1[y6][x6];
		u[y7][x7]=s[y7][x7]=s1[y7][x7];
		u[y8][x8]=s[y8][x8]=s1[y8][x8];

			/*
		 	 * go through the latin square to guess 
			 * the values of certain squares
		 	 */

			fin = 0;
			fill();
			if (fin) print();
		}
}

