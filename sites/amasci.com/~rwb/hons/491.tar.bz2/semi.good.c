#include <stdio.h>
#define SIZE 5
#define CRITSIZE 7

struct bitmap
{
	int count;
	int values[SIZE+1];
};
long count = 0;

void print(int s[SIZE][SIZE]);

struct bitmap
testone(int s[SIZE][SIZE], int a, int b)
{
	struct bitmap bm;
	int t[SIZE+1],that,i;
	for (i = 1; i <= SIZE; i++)
	{
		t[i] = 0;
		bm.values[i] = 0;
	}
	bm.count = 0;
	for (i = 0; i < SIZE; i++)
		t[s[a][i]] = t[s[i][b]] = 1;
	for (i = 1; i <= SIZE; i++)
		if (!t[i])
		{
			bm.values[i] = 1;
			that = i;
			bm.count ++;
		}

	if (bm.count == 1)
		{s[a][b] = that;}

	return bm;
}

int
testtwo(int s[SIZE][SIZE], int a, int b, struct bitmap bm)
{
	int t[SIZE+1],u[SIZE+1],that,row=0,col=0,i,j,c;
	for (i = 0; i < SIZE; i++)
	{
		if (!s[a][i]) row++; /* count number of empty elts in row */
		if (!s[i][b]) col++; /* count number of empty elts in col */
	}

	for (i = 1; i <= SIZE; i++)
		t[i] = u[i] = 0;	

	for (i = 0; i < SIZE; i++)
		for (j = 0; j < SIZE; j++)
		{
			if (!s[a][j] && i!=a && j!=b)  /* */
				u[s[i][j]]++;
			if (!s[i][b] && i!=a && j!=b)  /* */
				t[s[i][j]]++;
		}
	i = 0;	
	for (c=1; c<=SIZE; c++)
	{
		if (bm.values[c])
		{
			if (t[c] == col-1) {i++;that=c;}
			else if (u[c] == row-1) {i++;that=c;}
		}
	}
	if (i==1) {s[a][b] = that;return 1;}
	if (i>1) {printf("argh!!!!\n");print(s);}
	return 0;
}

void
print(int s[SIZE][SIZE])
{
	int             x, y;
	for (y = 0; y < SIZE; y++) 
	{
		for (x = 0; x < SIZE; x++) 
		{
			printf("%d", s[y][x]);
		} 
		printf(" ");
	} 
	printf("\n");
}

int fill(int s[SIZE][SIZE])
{
	struct bitmap ret;
	int a=0,b=0,changed,mod=1,flag=0,mod1=1;
	/* go through each element in the latin square */
	/* and test whether that element has a forced */
	/* completion. if not, move on to semi-strong */
	while (mod)
	{
		mod=0;
		while (mod1)
		{
			mod1=0;
			a=0;
			b=0;
			while (a*SIZE+b < SIZE*SIZE)
			{
				if (!s[a][b])
				{
					ret=testone(s, a, b);
					if (ret.count == 0) return 0;
					changed = ret.count;
					if (!mod1 && changed==1)
						mod1 = 1;
					if (changed==1) {flag++;}
				}
				b++; if (b==SIZE) {a++;b=0;}
			}
		}
			a=0;
			b=0;
			changed=0;
			while (a*SIZE+b < SIZE*SIZE)
			{
				if (!s[a][b])
				{
					ret=testone(s,a,b);
					if (ret.count == 1) {printf("%d argh\n",count);print(s);}
					if (ret.count == 0) return 0;
					changed=testtwo(s,a,b,ret);
					if (!mod && changed)
						mod = 1;
					/* if changed, go back to forced filling */
				}
				if (changed) {flag++;mod1=1;break;}
				b++; if (b==SIZE) {a++;b=0;}
			}
	}
	return (flag==SIZE*SIZE-CRITSIZE);
}

int
main(int argc, char **argv)
{
	int             s[SIZE][SIZE], u[SIZE][SIZE];
	int             a, b; 
	int j[CRITSIZE],x[CRITSIZE],y[CRITSIZE];
	int s1[5][5]={{1,2,3,4,5},{2,1,4,5,3},{3,5,1,2,4},{4,3,5,1,2},{5,4,2,3,1}};
	for (j[6] = 0       ; j[6] <= SIZE * SIZE - 7; j[6]++)
	for (j[5] = j[6] + 1; j[5] <= SIZE * SIZE - 6; j[5]++)
	for (j[4] = j[5] + 1; j[4] <= SIZE * SIZE - 5; j[4]++)
	for (j[3] = j[4] + 1; j[3] <= SIZE * SIZE - 4; j[3]++)
	for (j[2] = j[3] + 1; j[2] <= SIZE * SIZE - 3; j[2]++)
	for (j[1] = j[2] + 1; j[1] <= SIZE * SIZE - 2; j[1]++)
	for (j[0] = j[1] + 1; j[0] <= SIZE * SIZE - 1; j[0]++)
	{
		/* fill the latin square with zeros */
		count++;
		if (count % 100000 == 0) 
		{
			/*printf("count = %d\n",count);*/
			fflush(stdout);
		}
		for (a = 0; a < SIZE; a++) {
			for (b = 0; b < SIZE; b++) {
				s[a][b] = u[a][b] = 0;
			}
		}

		/* put the relevant entries in */	

		for (a = 0; a < CRITSIZE; a++)
		{
			x[a] = j[a] % SIZE; y[a] = j[a] / SIZE;
			u[y[a]][x[a]] = s[y[a]][x[a]] = s1[y[a]][x[a]];
		}
	         /*
		 * go through the latin square to guess 
	         * the values of certain squares
		 */
		/* if there is one unique completion
		   then print out the value */
		if(fill(s))print(u);
	}
}
