#include <stdio.h>
#include <sys/time.h>
/* program to generate random latin square */
/* Richard Bean rwb@maths.uq.edu.au 20/5/1997 */

int s[16][16];
int size;

void output()
{
	int c,d;
	for (c = 0; c < size; c++)
	{
		for (d = 0; d < size; d++)
		{
			printf("%4d",s[c][d]);
		}
		printf("\n");
	}
	printf("\n");
}

int check()
{
	/* is this a valid latin square? */
	int c,d,g,e;
	int dup[20];


	/* test for duplicates within columns */
	for (c=0; c<size; c++)
	{
		/* reset duplicate check array */
		for (e=0; e<19; e++)
			dup[e]=0;

		for (d=0; d<size; d++)
		{	
			g=s[c][d];
			if(g>0) 
			{
				dup[g]++;
				if (dup[g]>1) return 0;
			}
		}	
	}

	/* reset duplicate check array */
	for (c=0; c<size; c++)
		dup[c]=0;

	/* test for duplicates within rows */
	for (c=0; c<size; c++)
	{
		/* reset duplicate check array */
		for (e=0; e<19; e++)
			dup[e]=0;

		for (d=0; d<size; d++)
		{	
			g=s[d][c];
			if(g>=0) 
			{
				dup[g]++;
				if (dup[g]>1) return 0;
			}
		}	
	}
	return 1;
}

int main(int argc, char **argv)
{
	struct timeval tp;
	struct timezone tzp;
	int a,a2,b,c,x,d,e,f,old,good,count;
	tzp.tz_minuteswest = 0;
	tzp.tz_dsttime = 0;
	if (argc != 2) 
	{
		printf("usage: latin size\n");
		exit(1);
	}
	size = atoi(argv[1]);
	good=1;
	do
	{
	for (c = 0; c < size; c++)
		for (d = 0; d < size; d++)
			/* fill the latin square with negative rubbish */
			s[c][d] = -c*d-121*c-799*d-10;
	gettimeofday(&tp,&tzp);
	srand((int)tp.tv_usec);

	count=0;
	for (c = 0; c < size*size; c++)
	{
			/* pick a random unfilled square */
			x=0;
			do
			{
				/* pick a random unfilled square */
				do
				{
					e=rand()%size; 
					f=rand()%size; 
				}
				while(s[e][f]>=0);

				/* fill it */
				old = s[e][f];
				s[e][f] = (rand()%size)+1;
				x=check();
				if (!x) 
				{	
					/*printf("this square fails:\n");
					output();*/
					count++;
					s[e][f]=old;
				}
				if (count>10) break;
			}
			while(!x);
			if (count>10) break;
	}
	if (c==size*size) good = 0;
	}
	while(good);
	printf("this is the final result:\n");
	output();
	return 0;
}
