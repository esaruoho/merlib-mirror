/*
 * four.c: A program to create 4x4 latin squares from critical sets of
 * various sizes, then output statistics on those critical sets. Richard
 * Bean, 9 July 1997.  rwb@maths.uq.edu.au
 */

#include <sys/time.h>
#include <stdio.h>

int             s[25][25], u[25][25];
int             n;
int             changed;
long            tally[2][16];
int             f[2];

void 
print()
{
			int a,b;
			printf("start\n");
			for (a = 0; a < n; a++) {
				for (b = 0; b < n;
				     b++) {
					printf("%d", u[a][b]);
				} printf("\n");
			} for (a =
			       0; a < n; a++)
				printf("-");
			printf("\n");
			for (a = 0; a <
			     n; a++) {
				for (b = 0; b < n; b++) {
					printf("%d", s[a][b]);
				} printf("\n");
			}
			printf("end\n");
}

int
testone(int a, int b)
{
	int             t[25];
	int             that;
	int             i;
	int             goodflag = 0;
	for (i = 0; i < 25; i++)
		t[i] = 0;
	for (i = 0; i < n; i++)
		t[s[a][i]] = t[s[i][b]] = 1;
	for (i = 1; i <= n; i++)
		if (t[i])
			goodflag++;
		else
			that = i;
	if (goodflag == n - 1)
		changed = s[a][b] = that;
}

int
det()
{
	/*
	 * returns 0 if 4x4 latin square is made up of 2 2x2 latin squares,
	 * or 1 otherwise
	 */
	int             t[5];
	int             i, j;
	for (i = 0; i <= 4; i++)
		t[i] = 0;
	for (i = 2; i <= 3; i++) {
		for (j = 2; j <= 3; j++) {
			t[s[i][j]]++;
		}
	}
	for (i = 0; i <= 1; i++) {
		for (j = 0; j <= 1; j++) {
			t[s[i][j]]++;
		}
	}
	if ((t[3] == 0 && t[4] == 0) || (t[3] == 4 && t[4] == 4))
		return 0;
	else
		return 1;
}


int
main(int argc, char **argv)
{
	int             a, b, n2, c, d, fin, de, flag;
	long            bigger;
	long            count = 0;
	int             hugeflag = 1;
	int             test[25];
	struct timeval  tp;
	struct timezone tzp;
	tzp.tz_minuteswest = 0;
	tzp.tz_dsttime = 0;
	if (argc != 3) {
		printf("usage: latin size guesses\n");
		exit(1);
	}
	f[1] = f[0] = 0;
	n = atoi(argv[1]);
	n2 = atoi(argv[2]);

	/* generate finished latin squares loop */
	for (bigger = 0; bigger < 1000; bigger++) {
		gettimeofday(&tp, &tzp);
		srand((int) tp.tv_usec);

		while (hugeflag) {

			/* fill the latin square with zeros */
			/* printf("filling...\n"); */

			for (a = 0; a < n; a++) {
				for (b = 0; b < n; b++) {
					s[a][b] = u[a][b] = 0;
				}
			}

			for (a = 0; a < n2; a++) {
				int             x;
				do {
					c = rand() % n;
					d = rand() % n;
				} while (s[c][d]);
				x = (rand() % n) + 1;
				s[c][d] = u[c][d] = x;
			}
			/*
			 * go through the latin square to guess the values of
			 * certain squares
			 */
			flag = 1;
			while (flag) {
				count++;
				for (a = 0; a < n; a++) {
					for (b = 0; b < n; b++) {
						changed = 0;
						if (!s[a][b])
							testone(a, b);
						if (changed)
							break;
					}
					if (changed)
						break;
				}
				fin = 1;

				/* test if any of the elements are zero */
				for (a = 0; a < n; a++) {
					for (b = 0; b < n; b++) {
						if (s[a][b] == 0)
							fin = 0;
					}
				}
				if (fin) {
					/* test if it is a latin square */
					for (a = 0; a <= n; a++)
						test[a] = 0;
					for (a = 0; a < n; a++) {
						for (b = 0; b < n; b++) {
							test[s[a][b]]++;
						}
						for (b = 1; b < n; b++)
							if (test[b] != 1)
								{printf("row %d count is %d\n",b,test[b]);print();fin = 0;}
						for (a = 0; a <= n; a++)
							test[a] = 0;
					}
					for (a = 0; a < n; a++)
						test[a] = 0;
					for (a = 0; a < n; a++) {
						for (b = 0; b < n; b++) {
							test[s[b][a]]++;
						}
						for (b = 1; b < n; b++)
							if (test[b] != 1)
								{printf("column %d count is %d\n",b,test[b]);print();fin = 0;}
						for (a = 0; a <= n; a++)
							test[a] = 0;
					}
				}
				if (fin) {
					flag = 0;
					break;
				}
				if (!changed)
					break;

				if (changed)
					changed = 0;
			}
			/*
			 * if (count % 10000 == 0) printf(" count =
			 * %ld\n",count);
			 */
			if (fin) {
				hugeflag = 0;
				break;
			}
		}
		flag = 1;
		hugeflag = 1;

		/* printf("looked at %ld squares\n", count); */
		count = 0;
		de = det();
		f[de]++;
		/* printf("det = %d\n", de); */

		for (a = 0; a < n; a++) {
			for (b = 0; b < n; b++) {
				if (u[a][b])
					tally[de][a * n + b]++;
			}
		}
	}

	printf("for 4x4 squares made up of 2x2 squares: (total %d)\n", f[0]);
	for (a = 0; a < n; a++) {
		for (b = 0; b < n; b++) {
			printf("%9d", tally[0][a * n + b]);
		}
		printf("\n");
	}

	for (a = 0; a < n; a++)
		printf("-");
	printf("\n");

	printf("for 4x4 squares not made up of 2x2 squares: (total %d)\n", f[1]);

	for (a = 0; a < n; a++) {
		for (b = 0; b < n; b++) {
			printf("%9d", tally[1][a * n + b]);
		}
		printf("\n");
	}
}
