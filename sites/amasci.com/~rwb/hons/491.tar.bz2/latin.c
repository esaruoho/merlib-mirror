#include <sys/time.h>
int main(int argc, char **argv)
{

	int cl,j,x,h,k,i,r,c,n,z[100],a[100][100];
	struct timeval tp;
	struct timezone tzp;
	tzp.tz_minuteswest=0;
	tzp.tz_dsttime=0;
	if (argc != 2)
	{
		printf("usage: latin size\n");
		exit(1);
	}
	n = atoi(argv[1]);
	gettimeofday(&tp,&tzp);
	srand((int)tp.tv_usec);
	for (r = 1; r <= n; r++)
	{
		/* 60 */ 
		sixty:
		for (c = 1; c <= n; c++) 
			z[c]=c; 
		j = n;
		for(c = 1; c <= n; c++) 
		{
			i = 0;
			/*80*/ 
			eighty:
			x = rand()%j+1;
			for(h = 1; h <= (r-1); h++)
			{
				if (i>50) 
				{
					goto sixty;
				}
				if (a[h][c] == z[x]) 
				{
					i = i + 1; 
					goto eighty;
				}
			}
			a[r][c] = z[x];
			j--;
			for(k = x; k <= j; k++)
				z[k] = z[k+1];
		}
		for(cl = 1; cl <= n; cl++)
		{
			printf("%3d",a[r][cl]);
		}
		printf("\n");
	}
}
