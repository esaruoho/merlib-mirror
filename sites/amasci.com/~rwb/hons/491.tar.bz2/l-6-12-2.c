#include <math.h>
#include <sys/time.h>
#include <stdlib.h>
#include <stdio.h>
#define SIZE 6

int             s[SIZE][SIZE], u[SIZE][SIZE];
int             n=SIZE;
int             changed;
/* not the back-circulant square */
int s1[6][6]={{1,2,3,4,5,6},{2,1,5,6,3,4},{3,6,1,5,4,2},{4,5,6,1,2,3},{5,4,2,3,6,1},{6,3,4,2,1,5}};

void            print();

int
testone(int a, int b)
{
	int             t[25];
	int             that;
	int             i;
	int             goodflag = 0;
	for (i = 0; i <=n; i++)
		t[i] = 0;
	for (i = 0; i < n; i++)
		t[s[a][i]] = t[s[i][b]] = 1;
	for (i = 1; i <= n; i++)
		if (t[i])
			goodflag++;
		else
			that = i;
	if (goodflag == n - 1)
	{
		s[a][b] = that;
		return 1;
	}
	else
		return 0;
}

void
print()
{
	int             a, b;
	for (a = 0; a < n; a++) 
	{
		for (b = 0; b < n; b++) 
		{
			printf("%d", u[a][b]);
		} 
		printf(" ");
	} 
	printf("\n");
}

fill()
{
	int a,b,changed,mod=1,flag=0;
	while (mod) {
		/* go through each element in the latin square */
		/* and test whether that element has a forced */
		/* completion. */
		mod = 0;
		for (a = 0; a < n; a++) {
			for (b = 0; b < n; b++) {
				if (!s[a][b])
				{
					changed = testone(a, b);
					flag += changed;
					if (!mod && changed)
						mod = 1;
				}
			}
		}
	}
	return (flag == n*n - 12);
}

int
main(int argc, char **argv)
{
	int             a, b;
	int j0,j1,j2,j3,j4,j5,j6,j7,j8,j9,j10,j11,x0,x1,x2,x3,x4,x5,x6,x7,x8,x9,x10,x11,y0,y1,y2,y3,y4,y5,y6,y7,y8,y9,y10,y11;
	long            count = 0;
	n = 6; 

	for (j0 = 0; j0 <= 24; j0++)
	for (j1 = j0+1; j1 <= 25; j1++)
	for (j2 = j1+1; j2 <= 26; j2++)
	for (j3 = j2+1; j3 <= 27; j3++)
	for (j4 = j3+1; j4 <= 28; j4++)
	for (j5 = j4+1; j5 <= 29; j5++)
	for (j6 = j5+1; j6 <= 30; j6++)
	for (j7 = j6+1; j7 <= 31; j7++)
	for (j8 = j7+1; j8 <= 32; j8++)
	for (j9 = j8+1; j9 <= 33; j9++)
	for (j10 = j9+1; j10 <= 34; j10++)
	for (j11 = j10+1; j11 <= 35; j11++){

		count ++ ;
		if (count % 1000000 == 0) printf("count = %d\n",count);
		/* fill the latin square with zeros */

		for (a = 0; a < n; a++) {
			for (b = 0; b < n; b++) {
				s[a][b] = u[a][b] = 0;
			}
		}

		/* put the relevant entries in */	

		x0  = j0%6;  y0  = j0/6;
		x1  = j1%6;  y1  = j1/6;
		x2  = j2%6;  y2  = j2/6;
		x3  = j3%6;  y3  = j3/6;
		x4  = j4%6;  y4  = j4/6;
		x5  = j5%6;  y5  = j5/6;
		x6  = j6%6;  y6  = j6/6;
		x7  = j7%6;  y7  = j7/6;
		x8  = j8%6;  y8  = j8/6;
		x9  = j9%6;  y9  = j9/6;
		x10 = j10%6; y10 = j10/6;
		x11 = j11%6; y11 = j11/6;

		u[y0][x0]=s[y0][x0]=s1[y0][x0];
		u[y1][x1]=s[y1][x1]=s1[y1][x1];
		u[y2][x2]=s[y2][x2]=s1[y2][x2];
		u[y3][x3]=s[y3][x3]=s1[y3][x3];
		u[y4][x4]=s[y4][x4]=s1[y4][x4];
		u[y5][x5]=s[y5][x5]=s1[y5][x5];
		u[y6][x6]=s[y6][x6]=s1[y6][x6];
		u[y7][x7]=s[y7][x7]=s1[y7][x7];
		u[y8][x8]=s[y8][x8]=s1[y8][x8];
		u[y9][x9]=s[y9][x9]=s1[y9][x9];
		u[y10][x10]=s[y10][x10]=s1[y10][x10];
		u[y11][x11]=s[y11][x11]=s1[y11][x11];

			/*
		 	 * go through the latin square to guess 
			 * the values of certain squares
		 	 */

			if (fill()) print();
		}
}

