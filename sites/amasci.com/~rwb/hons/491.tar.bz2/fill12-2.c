#include <stdio.h>
#define SIZE 12
#define CRITSIZE 64

int
main()
{
	int s[12][12]={{ 0, 0, 3, 0, 0, 0,10, 0, 0, 0, 0, 7},
		       {11, 0, 0, 0, 9, 0, 0, 0, 0, 0, 8, 0},
		       { 0,12, 0, 0, 0, 1, 0, 4, 9, 0, 0, 2},
		       { 0, 0, 0, 9,12, 0, 0, 0,10, 8, 7, 0},
		       { 0, 0, 7,12, 2, 0, 0, 6, 0, 1, 9, 0},
		       { 1, 0, 0, 0,10, 0, 0, 0, 0, 2,11, 8},
		       { 9, 0, 0, 7, 0, 0, 4, 0, 0, 5, 0,11},
		       { 3, 4, 0, 0,11, 0, 2, 0,12, 0, 6, 5},
		       { 6, 1, 5, 3, 7,12, 0, 2, 0, 0, 0,10},
                       { 5, 0,11, 0, 0, 3, 7, 0, 2, 0, 0, 0},
		       { 0, 6, 4, 1, 0, 5, 0, 3, 7, 0, 0, 0},
		       { 0, 2, 0,10, 0, 0, 6, 8, 5, 4, 0, 0}};
	fill(s,0,0);
}

struct bitmap
{
	int count;
	int values[SIZE+1];
};
long count = 0;

struct bitmap
testone(int s[SIZE][SIZE], int a, int b)
{
	struct bitmap bm;
	int             t[SIZE+1];
	int             that;
	int             i;
	for (i = 1; i <= SIZE; i++)
	{
		t[i] = 0;
		bm.values[i] = 0;
	}
	bm.count = 0;
	for (i = 0; i < SIZE; i++)
		t[s[a][i]] = t[s[i][b]] = 1;
	for (i = 1; i <= SIZE; i++)
		if (!t[i])
		{
			bm.values[i] = 1;
			that = i;
			bm.count ++;
		}
	/* if (bm.count == 1)
		s[a][b] = that; */
	return bm;
}

void
print(int s[SIZE][SIZE])
{
	int             x, y;
	for (y = 0; y < SIZE; y++) 
	{
		for (x = 0; x < SIZE; x++) 
		{
			printf("%3d", s[y][x]);
		} 
		printf("\n");
	} 
}

int fill(int s[SIZE][SIZE], int level, int pos)
{
	/* for this function, we are assuming that at 
	   some point the function will return 1 for
	   a forced latin square */
	/* also: during forcing: if no element could
	   possibly *be* in a position, then there
	   is no point in continuing. */
	int a,b,c,flag = 0, poss = 0, mod=1;
	struct bitmap ret;
	if (level == SIZE * SIZE - CRITSIZE) 
		{print(s);return 1;}

	/* now try all possibilities */
		a = pos % SIZE; b = pos / SIZE;
		while ( b*SIZE + a < SIZE * SIZE)
		{
			if (!s[a][b])
			{
				ret = testone(s,a,b);
				if (ret.count == 0) return 0;
				for (c = 1; c <= SIZE; c++)
				{	
					if (ret.values[c])
					{
						s[a][b] = c;
						poss += fill(s, level+1, b*SIZE + a+ 1);
						s[a][b] = 0;
					}
					/* return immediately if > 1 */
					if (poss>1) return poss;
				}
				/* if one square fails,
				   forget about the rest */
				if (poss == 0) return 0;
			}			
			a++; if (a==SIZE) {b++; a=0;}
		}
	return poss;
}
