#include <math.h>
#include <sys/time.h>
#include <stdlib.h>
#include <stdio.h>
#define SIZE 7
#define CRITSIZE 14
long count = 0;
int
testone(int s[SIZE][SIZE],int a, int b)
{
	int             t[SIZE+1];
	int             that;
	int             i;
	int             goodflag = 0;
	for (i = 1; i <= SIZE; i++)
		t[i] = 0;
	for (i = 0; i < SIZE; i++)
		t[s[a][i]] = t[s[i][b]] = 1; /* set both to 1 */
	for (i = 1; i <= SIZE; i++)
		if (t[i])
			goodflag++;
		else
			that = i;
	if (goodflag == SIZE - 1)
	{
		s[a][b] = that;
		return 1;
	}
	else
		return 0;
}

void
print(int s[SIZE][SIZE])
{
	int             a, b;
	for (a = 0; a < SIZE; a++) 
	{
		for (b = 0; b < SIZE; b++) 
		{
			printf("%d", s[a][b]);
		} 
		printf(" ");
	} 
	printf("\n");
}

int fill(int s[SIZE][SIZE])
{
		int a,b,changed,mod=1,flag=0;

		while (mod) {
			/* go through each element in the latin square */
			/* and test whether that element has a forced */
			/* completion. */
			mod = 0;
			for (a = 0; a < SIZE; a++) {
				for (b = 0; b < SIZE; b++) {
					if (!s[a][b])
					{
						changed=testone(s, a, b);
						flag += changed;
						if (!mod && changed)
							mod = 1;
					}
			}
		}
	}
	return (flag==SIZE*SIZE-CRITSIZE);
}

int
main()
{
	int             a, b, c, n, d; long p;
	/* 1.1.1 */ 
	int s1[SIZE][SIZE]={{1,2,3,4,5,6,7},{2,3,4,5,6,7,1},{3,4,5,6,7,1,2},{4,5,6,7,1,2,3},{5,6,7,1,2,3,4},{6,7,1,2,3,4,5},{7,1,2,3,4,5,6}};
	int j[CRITSIZE],x[CRITSIZE],y[CRITSIZE], s[SIZE][SIZE], u[SIZE][SIZE];
	struct timeval  tp;
	struct timezone tzp;
	double lc, l2, ld;
	tzp.tz_minuteswest = 0;
	tzp.tz_dsttime = 0;

	/* fill the latin square with zeros */
	p = 1;
	gettimeofday(&tp, &tzp);
	srand((int) tp.tv_usec);
	while (1)
	{
		count++;
		if (count == p)
		{
			printf("count = %ld\n",count);
			p = count + count;
		}
		for (a = 0; a < SIZE; a++) {
			for (b = 0; b < SIZE; b++) {
				s[a][b] = u[a][b] = 0;
			}
		}

		/* put the relevant entries in */	

		for (a = 0; a<CRITSIZE; a++)
		{
			do {
				c = rand() % SIZE;
				d = rand() % SIZE;
			} while (s[c][d]);
			s[c][d] = u[c][d] = s1[c][d];
		}

		/*
		 * go through the latin square to guess 
		 * the values of certain squares
		 */

		if (fill(s)) {print(u);exit(0);}
	}
}
