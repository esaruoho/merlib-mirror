/* A program to generate all strongly critical sets for
   a Latin square */

#include <stdio.h>
#define SIZE 5     /* the order of the Latin square */
#define CRITSIZE 8 /* the size of the critical set being searched for */

int
testone(int s[SIZE][SIZE],int a, int b)
{
        /* A function for testing if the element in row a, 
           column b of the Latin square in the array s 
           has a forced completion.  It is assumed to be
           an empty square. */

        int             t[SIZE+1];
        int             that;
        int             i;
        int             goodflag = 0;

        /* clear the test array */
        for (i = 1; i <= SIZE; i++)
                t[i] = 0;

        /* for every element in the same row and column
           as the element being tested, set the
           corresponding test array element to be 1 */
        for (i = 0; i < SIZE; i++)
                t[s[a][i]] = t[s[i][b]] = 1;

        /* count the number of different elements used
           in that row and column */
        for (i = 1; i <= SIZE; i++)
                if (t[i])
                        goodflag++;
                else
                        that = i;
        /* if that element has a forced completion,
           change it, and return a flag indicating
           that the element has changed. */
        if (goodflag == SIZE - 1)
        {
                s[a][b] = that;
                return 1;
        }
        else
                return 0;
}

void
print(int s[SIZE][SIZE])
{
        /* print out the Latin square contained in the array s */
        int             a, b;
        for (a = 0; a < SIZE; a++) 
        {
                for (b = 0; b < SIZE; b++) 
                {
                        printf("%d", s[a][b]);
                } 
                printf(" ");
        } 
        printf("\n");
}

int fill(int s[SIZE][SIZE])
{
		/* this function tries to complete the partial
		   Latin square supplied in the array s.  It
		   returns 1 if successful and 0 otherwise. */
                int a,b,changed,mod=1,flag=0;

                while (mod) {
                        /* go through each element in the Latin square */
                        /* and test whether that element has a forced */
                        /* completion. */
                        mod = 0;
                        for (a = 0; a < SIZE; a++) {
                                for (b = 0; b < SIZE; b++) {
                                        if (!s[a][b])
                                        {
                                                changed=testone(s, a, b);
						if (changed)
							print(s);
                                                flag += changed;
                                                /* changed? then go through
                                                   loop again */
                                                if (!mod && changed)
                                                        mod = 1;
                                        }
                        }
                }
        }
        /* having counted the number of elements that have
           changed in the flag variable, return 1 if
           the square has been successfully completed */
        return (flag==SIZE*SIZE-CRITSIZE);
}

int
main()
{
        int             a, b;
        /* 1.1.1 - the back circulant Latin square of order 5 */ 
        int s[5][5]={{5,0,3,4,0},{2,0,0,0,0},{0,5,0,0,0},{4,0,0,1,0},{0,0,0,0,1}};
        int j[CRITSIZE],x[CRITSIZE],y[CRITSIZE], u[SIZE][SIZE];

        for (a = 0; a<CRITSIZE; a++)
        for (b = 0; a<CRITSIZE; a++)
        u[a][b]=s[a][b];
	fill(s);
}
