#include <stdio.h>
#define SIZE 12
#define CRITSIZE 63

int
testone(int s[SIZE][SIZE],int a, int b)
{
	int             t[SIZE+1];
	int             that;
	int             i;
	int             goodflag = 0;
	for (i = 1; i <= SIZE; i++)
		t[i] = 0;
	for (i = 0; i < SIZE; i++)
		t[s[a][i]] = t[s[i][b]] = 1; /* set both to 1 */
	for (i = 1; i <= SIZE; i++)
		if (t[i])
			goodflag++;
		else
			that = i;
	if (goodflag == SIZE - 1)
	{
		s[a][b] = that;
		return 1;
	}
	else
		return 0;
}

void
print(int s[SIZE][SIZE])
{
	int             a, b;
	for (a = 0; a < SIZE; a++) 
	{
		for (b = 0; b < SIZE; b++) 
		{
			printf("%3d", s[a][b]);
		} 
		printf("\n");
	} 
}

int fill(int s[SIZE][SIZE])
{
		int a,b,changed,mod=1,flag=0;

		while (mod) {
			/* go through each element in the latin square */
			/* and test whether that element has a forced */
			/* completion. */
			mod = 0;
			for (a = 0; a < SIZE; a++) {
				for (b = 0; b < SIZE; b++) {
					if (!s[a][b])
					{
						changed=testone(s, a, b);
						flag += changed;
						if (!mod && changed)
							mod = 1;
					}
			}
		}
	}
	return (flag==SIZE*SIZE-CRITSIZE);
}

int
main()
{
	int a,b,c;
	/* 1.1.1 */ 
	int s[12][12]={{ 0, 0, 3, 0, 0, 0,10, 0, 0, 0, 0, 7},
		       {11, 0, 0, 0, 9, 0, 0, 0, 0, 0, 8, 0},
		       { 0,12, 0, 0, 0, 1, 0, 4, 9, 0, 0, 2},
		       { 0, 0, 0, 9,12, 0, 0, 0,10, 8, 7, 0},
		       { 0, 0, 7,12, 2, 0, 0, 6, 0, 1, 9, 0},
		       { 1, 0, 0, 0,10, 0, 0, 0, 0, 2,11, 8},
		       { 9, 0, 0, 7, 0, 0, 4, 0, 0, 5, 0,11},
		       { 3, 4, 0, 0,11, 0, 2, 0,12, 0, 6, 5},
		       { 6, 1, 5, 3, 7,12, 0, 2, 0, 0, 0,10},
                       { 5, 0,11, 0, 0, 3, 7, 0, 2, 0, 0, 0},
		       { 0, 6, 4, 1, 0, 5, 0, 3, 7, 0, 0, 0},
		       { 0, 2, 0,10, 0, 0, 6, 8, 5, 4, 0, 0}};
	/*for (a=0;a<SIZE;a++)
		for(b=0;b<SIZE;b++)
			if (s[a][b])printf("%d\n",s[a][b]);*/
	fill(s); print(s);
	c=0;
	for (a=0;a<SIZE;a++)
		for(b=0;b<SIZE;b++)
			if (s[a][b])c++;
	printf("%d\n",c);
}
