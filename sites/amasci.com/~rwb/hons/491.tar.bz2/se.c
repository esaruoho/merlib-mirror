/* A program to generate all semi-strongly critical sets for
   a latin square */

#include <stdio.h>
#define SIZE 6     /* the order of the latin square */
#define CRITSIZE 9 /* the size of the critical set being searched for */

struct bitmap
{
        int count;
        int values[SIZE+1];
};
long count = 0,fillc1=0,fillc2=0;
long se1[500000],se2[500000];

void print(int s[SIZE][SIZE]);

struct bitmap
testone(int s[SIZE][SIZE], int a, int b)
{
        /* A function for testing if the element in row a,
        column b of the latin square in the array s 
        has a forced completion.  It is assumed to be
        an empty square. */

        struct bitmap bm;
        int t[SIZE+1],that,i;
	fillc1++;
        /* clear the test and values array */
        for (i = 1; i <= SIZE; i++)
        {
                t[i] = 0;
                bm.values[i] = 0;
        }
        bm.count = 0;
        /* for every element in the same row and column
           as the element being tested, set the
           corresponding test array element to be 1 */
        for (i = 0; i < SIZE; i++)
                t[s[a][i]] = t[s[i][b]] = 1;

        /* keep track of all the different elements used
           in that row and column */
        for (i = 1; i <= SIZE; i++)
                if (!t[i])
                {
                        bm.values[i] = 1;
                        that = i;
                        bm.count ++;
                }

        /* if the completion was forced changed that element */
        if (bm.count == 1)
                {s[a][b] = that;}

        /* return the structure containing which elements
           were used so that each can be tried in that
           position */
        return bm;
}

int
testtwo(int s[SIZE][SIZE], int a, int b, struct bitmap bm)
{
        /* This function looks through the latin square s
           and attempts to determine if the element
           in row a, column b, is forced by the elements
           not in that row, or not in that column (see
           thesis for a better explantation) */

        int t[SIZE+1],u[SIZE+1],that,row=0,col=0,i,j,c;
	fillc2++;
        for (i = 0; i < SIZE; i++)
        {
                if (!s[a][i]) row++; /* count number of empty elts in row */
                if (!s[i][b]) col++; /* count number of empty elts in col */
        }

        for (i = 1; i <= SIZE; i++)
                t[i] = u[i] = 0;        

        /* too complicated to explain here.   see thesis */
        for (i = 0; i < SIZE; i++)
                for (j = 0; j < SIZE; j++)
                {
                        if (!s[a][j] && i!=a && j!=b)  /* same row */
                                u[s[i][j]]++;
                        if (!s[i][b] && i!=a && j!=b)  /* same col */
                                t[s[i][j]]++;
                }
        i = 0;  
        for (c=1; c<=SIZE; c++)
        {
                if (bm.values[c])
                {
                        if (t[c] == col-1) {i++;that=c;}
                        else if (u[c] == row-1) {i++;that=c;}
                }
        }
        if (i==1) {s[a][b] = that;return 1;} /* change that element */
        if (i>1) {printf("argh!!!!\n");print(s);} /* should not occur */
        return 0; /* if no change occurred, return 0 */
}

void
print(int s[SIZE][SIZE])
{
        /* print the latin square */
        int             x, y;
        for (y = 0; y < SIZE; y++) 
        {
                for (x = 0; x < SIZE; x++) 
                {
                        printf("%d", s[y][x]);
                } 
                printf(" ");
        } 
        printf("\n");
}

int fill(int s[SIZE][SIZE])
{
        struct bitmap ret;
        int a=0,b=0,changed,mod=1,flag=0,mod1=1;
        /* go through each element in the latin square */
        /* and test whether that element has a forced */
        /* completion. if not, move on to semi-strong */
        while (mod)
        {
                mod=0;
                while (mod1)
                {
                        mod1=0;
                        a=0;
                        b=0;
                        while (a*SIZE+b < SIZE*SIZE)
                        {
                                if (!s[a][b])
                                {
                                        ret=testone(s, a, b);
                                        if (ret.count == 0) return 0;
                                        changed = ret.count;
                                        if (!mod1 && changed==1)
                                                mod1 = 1;
                                        if (changed==1) {flag++;}
                                }
                                b++; if (b==SIZE) {a++;b=0;}
                        }
                }
                        a=0;
                        b=0;
                        changed=0;
                        while (a*SIZE+b < SIZE*SIZE)
                        {
                                if (!s[a][b])
                                {
                                        ret=testone(s,a,b);
                                        if (ret.count == 1)
                                        {
                                                /* shouldn't occur */
                                                printf("%d argh\n",count);
                                                print(s);
                                        }
                                        if (ret.count == 0) return 0;
                                        /* pass possible elements
                                           to next stage of testing */
                                        changed=testtwo(s,a,b,ret);
                                        if (!mod && changed)
                                                mod = 1;
                                        /* if changed, go back to 
                                           forced filling */
                                }
                                if (changed) {flag++;mod1=1;break;}
                                b++; if (b==SIZE) {a++;b=0;}
                        }
        }
        return (flag==SIZE*SIZE-CRITSIZE);
}

int
main(int argc, char **argv)
{
        int             s[SIZE][SIZE], u[SIZE][SIZE];
        int             a, b; 
        int j[CRITSIZE],x[CRITSIZE],y[CRITSIZE];
        int s1[6][6]={{1,2,3,4,5,6},{2,3,4,5,6,1},{3,4,5,6,1,2},{4,5,6,1,2,3},{5,6,1,2,3,4},{6,1,2,3,4,5}};
	for (a = 0; a< 500000; a++) se1[a] = se2[a] =0 ;
        for (j[8] = 0;        j[8] <= SIZE * SIZE - 9; j[8]++)
        for (j[7] = j[8] + 1; j[7] <= SIZE * SIZE - 8; j[7]++)
        for (j[6] = j[7] + 1; j[6] <= SIZE * SIZE - 7; j[6]++)
        for (j[5] = j[6] + 1; j[5] <= SIZE * SIZE - 6; j[5]++)
        for (j[4] = j[5] + 1; j[4] <= SIZE * SIZE - 5; j[4]++)
        for (j[3] = j[4] + 1; j[3] <= SIZE * SIZE - 4; j[3]++)
        for (j[2] = j[3] + 1; j[2] <= SIZE * SIZE - 3; j[2]++)
        for (j[1] = j[2] + 1; j[1] <= SIZE * SIZE - 2; j[1]++)
        for (j[0] = j[1] + 1; j[0] <= SIZE * SIZE - 1; j[0]++)
        {
                /* fill the latin square with zeros */
                count++;
                for (a = 0; a < SIZE; a++) {
                        for (b = 0; b < SIZE; b++) {
                                s[a][b] = u[a][b] = 0;
                        }
                }

                /* put the relevant entries in */       

                for (a = 0; a < CRITSIZE; a++)
                {
                        x[a] = j[a] % SIZE; y[a] = j[a] / SIZE;
                        u[y[a]][x[a]] = s[y[a]][x[a]] = s1[y[a]][x[a]];
                }
                 /*
                 * go through the latin square to guess 
                 * the values of certain squares
                 */
                /* if there is one unique completion
                   then print out the value */
                a=fill(s);
		if (a) printf("fillc1 = %d, fillc2 = %d, a = %d\n",fillc1,fillc2,a);
		se1[fillc1]++;
		se2[fillc2]++;
		fillc1=fillc2=0;
        }
	for (a = 0; a<500000; a++)
		if (se1[a] || se2[a]) printf("se1[%d] = %d, se2[%d] = %d\n", a, se1[a], a, se2[a]);
}
