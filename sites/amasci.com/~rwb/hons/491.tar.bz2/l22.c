#include <math.h>
#include <sys/time.h>
#include <stdlib.h>
#include <stdio.h>

int             s[25][25], u[25][25];
int             n;
int             changed;
int s2[5][5]={{1,2,3,4,5},{2,3,4,5,1},{3,4,5,1,2},{4,5,1,2,3},{5,1,2,3,4}};
int s1[5][5]={{1,2,3,4,5},{2,1,4,5,3},{3,5,1,2,4},{4,3,5,1,2},{5,4,2,3,1}};

void            print();

int
testsquare()
{
	int             a, b, c;
	int             test[50];
	/* test if it is a latin square */

	/*
	 * how many times does each number occur in each column?
	 */

	/* initialise the array */

	for (a = 0; a <= n; a++)
		test[a] = 0;

	for (a = 1; a <= n; a++) {
		for (b = 0; b < n; b++) {
			for (c = 0; c < n; c++) {
				if (s[b][c] == a)
					test[c]++;
			}
		}
		for (b = 1; b < n; b++)
			if (test[b] > 1) {
				/*
				 * printf("the number %d occurs in column %d
				 * %d times\n", a, b+1, test[b]);
				 */
				/* print(); */
				return 0;
			}
		for (b = 0; b <= n; b++)
			test[b] = 0;
	}

	/*
	 * how many times does each number occur in each row?
	 */

	/* initialise the array */

	for (a = 0; a < n; a++)
		test[a] = 0;

	for (a = 1; a < n; a++) {
		for (b = 0; b < n; b++) {
			for (c = 0; c < n; c++) {
				if (s[b][c] == a)
					test[b]++;
			}
		}
		for (b = 1; b < n; b++)
			if (test[b] > 1) {
				/*
				 * printf("the number %d occurs in row %d %d
				 * times\n", a, b+1, test[b]);
				 */
				/* print(); */
				return 0;
			}
		for (b = 0; b <= n; b++)
			test[b] = 0;
	}
	return 1;
}

int
testone(int a, int b)
{
	int             t[25];
	int             that;
	int             i;
	int             goodflag = 0;
	for (i = 0; i < 25; i++)
		t[i] = 0;
	for (i = 0; i < n; i++)
		t[s[a][i]] = t[s[i][b]] = 1;
	for (i = 1; i <= n; i++)
		if (t[i])
			goodflag++;
		else
			that = i;
	if (goodflag == n - 1)
		changed = s[a][b] = that;
}

void
print()
{
	int             a, b;

	for (a = 0; a < n; a++) 
	{
		for (b = 0; b < n; b++) 
		{
			printf("%d", u[a][b]);
		} 
		printf(" ");
	} 
	printf("\n");
}

int
main(int argc, char **argv)
{
	int             a, b, flag, fin;
	int j1,j2,j3,j4,j5,j6,x1,x2,x3,x4,x5,x6,y1,y2,y3,y4,y5,y6;
	long            count = 0;
	n = 5;

	for (j1 = 0; j1 <= 19; j1++)
	for (j2 = j1+1; j2 <= 20; j2++)
	for (j3 = j2+1; j3 <= 21; j3++)
	for (j4 = j3+1; j4 <= 22; j4++)
	for (j5 = j4+1; j5 <= 23; j5++)
	for (j6 = j5+1; j6 <= 24; j6++) {

		/* fill the latin square with zeros */

		for (a = 0; a < n; a++) {
			for (b = 0; b < n; b++) {
				s[a][b] = u[a][b] = 0;
			}
		}

		/* put the relevant entries in */	

		x1 = j1%5 ; y1 = j1/5 ;
		x2 = j2%5 ; y2 = j2/5 ;
		x3 = j3%5 ; y3 = j3/5 ;
		x4 = j4%5 ; y4 = j4/5 ;
		x5 = j5%5 ; y5 = j5/5 ;
		x6 = j6%5 ; y6 = j6/5 ;

		u[y1][x1]=s[y1][x1]=s1[x1][y1];
		u[y2][x2]=s[y2][x2]=s1[x2][y2];
		u[y3][x3]=s[y3][x3]=s1[x3][y3];
		u[y4][x4]=s[y4][x4]=s1[x4][y4];
		u[y5][x5]=s[y5][x5]=s1[x5][y5];
		u[y6][x6]=s[y6][x6]=s1[x6][y6];

		/*
		 * go through the latin square to guess the values of certain
		 * squares
		 */

		flag = 1;
		while (flag) {
		/* go through each element in the latin square */
		/* and test whether that element has a forced */
		/* completion. */
		for (a = 0; a < n; a++) {
			for (b = 0; b < n; b++) {
				changed = 0;
				if (!s[a][b])
					testone(a, b);
				if (changed)
					break;
			}
			if (changed)
				break;
		}

		/* assume latin square is finished... */
		fin = 1;
		for (a = 0; a < n; a++) {
			for (b = 0; b < n; b++) {
				if (s[a][b] == 0)
					fin = 0;
			}
		}

		/* if it is finished, test if it is valid */
		if (fin) {
			fin = testsquare();
		}

		if (fin) {
			flag = 0;
			break;
		}

		/* if it did not change, break out */
		if (!changed) {
			flag = 0;
			break;
		}

		if (changed)
			changed = 0;
	}
	if (fin) print();
	}
}
