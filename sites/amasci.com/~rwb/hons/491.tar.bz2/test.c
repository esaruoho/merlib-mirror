#include <sys/time.h>
#include <stdio.h>

int             s[25][25], u[25][25];
int             n;
int             changed;

int 
testone(int a, int b)
{
	int             t[25];
	int             that;
	int             i;
	int             goodflag = 0;
	for (i = 0; i < 25; i++)
		t[i] = 0;
	for (i = 0; i < n; i++)
		t[s[a][i]] = t[s[i][b]] = 1;
	for (i = 1; i <= n; i++)
		if (t[i])
			goodflag++;
		else
			that = i;
	if (goodflag == n - 1)
		changed = s[a][b] = that;
}


void
print()
{
	int             a, b;
	printf("start\n");
	for (a = 0; a < n; a++) {
		for (b = 0; b < n;
		     b++) {
			printf("%d", u[a][b]);
		} printf("\n");
	} for (a =
	       0; a < n; a++)
		printf("-");
	printf("\n");
	for (a = 0; a <
	     n; a++) {
		for (b = 0; b < n; b++) {
			printf("%d", s[a][b]);
		} printf("\n");
	}
	printf("end\n");
}
int 
main(int argc, char **argv)
{
	int             a, b, n2, c, d;
	int             fin;
	int             test[25];
	long            count = 0;
	int             flag;
	int             hugeflag = 1;
	struct timeval  tp;
	struct timezone tzp;
	tzp.tz_minuteswest = 0;
	tzp.tz_dsttime = 0;
	if (argc != 3) {
		printf("usage: latin size guesses\n");
		exit(1);
	}
	while (hugeflag) {
		n = atoi(argv[1]);
		n2 = atoi(argv[2]);
		gettimeofday(&tp, &tzp);
		srand((int) tp.tv_usec);

		/* fill the latin square with zeros */

		for (a = 0; a < n; a++) {
			for (b = 0; b < n; b++) {
				s[a][b] = u[a][b] = 0;
			}
		}

		for (a = 0; a < n2; a++) {
			int             x;
			do {
				c = rand() % n;
				d = rand() % n;
			} while (s[c][d]);
			x = (rand() % n) + 1;
			s[c][d] = u[c][d] = x;
		}

		/*
		 * go through the latin square to guess the values of certain
		 * squares
		 */

		flag = 1;
		while (flag) {
			count++;
			for (a = 0; a < n; a++) {
				for (b = 0; b < n; b++) {
					changed = 0;
					if (!s[a][b])
						testone(a, b);
					if (changed)
						break;
				}
				if (changed)
					break;
			}
			fin = 1;
			for (a = 0; a < n; a++) {
				for (b = 0; b < n; b++) {
					if (s[a][b] == 0)
						fin = 0;
				}
			}

			if (fin) {
				/* test if it is a latin square */
				for (a = 0; a <= n; a++)
					test[a] = 0;
				for (a = 0; a < n; a++) {
					for (b = 0; b < n; b++) {
						test[s[a][b]]++;
					}
					for (b = 1; b < n; b++)
						if (test[b] != 1) {
							printf("row %d count is %d\n", b, test[b]);
							print();
							fin = 0;
						}
					for (a = 0; a <= n; a++)
						test[a] = 0;
				}
				for (a = 0; a < n; a++)
					test[a] = 0;
				for (a = 0; a < n; a++) {
					for (b = 0; b < n; b++) {
						test[s[b][a]]++;
					}
					for (b = 1; b < n; b++)
						if (test[b] != 1) {
							printf("column %d count is %d\n", b, test[b]);
							print();
							fin = 0;
						}
					for (a = 0; a <= n; a++)
						test[a] = 0;
				}
			}
			if (fin) {
				flag = 0;
				break;
			}
			if (!changed) {
				flag = 0;
				break;
			}
			if (changed)
				changed = 0;
		}
		/* if (count % 100000 == 0) printf(" count = %ld\n",count); */
		if (fin) {
			hugeflag = 0;
			break;
		}
	}
	if (fin) {
		for (a = 0; a < n; a++) {
			for (b = 0; b < n; b++) {
				printf("%3d", u[a][b]);
			}
			printf("\n");
		}
		for (a = 0; a < n; a++)
			printf("-");
		printf("\n");
		for (a = 0; a < n; a++) {
			for (b = 0; b < n; b++) {
				printf("%3d", s[a][b]);
			}
			printf("\n");
		}
	}
	printf("looked at %ld squares\n", count);
}
