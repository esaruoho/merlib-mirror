#include <stdio.h>
#define SIZE 20
int CRITSIZE;
int
testone(int **s,int a, int b)
{
	int             t[SIZE+1];
	int             that;
	int             i;
	int             goodflag = 0;
	for (i = 1; i <= SIZE; i++)
		t[i] = 0;
	for (i = 0; i < SIZE; i++)
		t[s[a][i]] = t[s[i][b]] = 1; /* set both to 1 */
	for (i = 1; i <= SIZE; i++)
		if (t[i])
			goodflag++;
		else
			that = i;
	if (goodflag == SIZE - 1)
	{
		s[a][b] = that;
		return 1;
	}
	else
		return 0;
}

void
print(int **s)
{
	int             a, b;
	for (a = 0; a < SIZE; a++) 
	{
		for (b = 0; b < SIZE; b++) 
		{
			printf("%d", s[a][b]);
		} 
		printf(" ");
	} 
	printf("\n");
}

int fill(int **s)
{
		int a,b,changed,mod=1,flag=0;

		while (mod) {
			/* go through each element in the latin square */
			/* and test whether that element has a forced */
			/* completion. */
			mod = 0;
			for (a = 0; a < SIZE; a++) {
				for (b = 0; b < SIZE; b++) {
					if (!s[a][b])
					{
						changed=testone(s, a, b);
						flag += changed;
						if (!mod && changed)
							mod = 1;
					}
			}
		}
	}
	return (flag==SIZE*SIZE-CRITSIZE);
}

int
main()
{
	/* 1.1.1 */ 
	char st[100];
	int size;
	int **s={{0,2,3,4,0,0},{3,0,0,0,0,4},{0,0,0,5,0,0},{0,4,6,0,0,1},{0,6,0,0,2,0},{6,0,0,0,1,0}};
	scanf("%s",st);
	size = strlen(st);
	fill(s); print(s);
}
