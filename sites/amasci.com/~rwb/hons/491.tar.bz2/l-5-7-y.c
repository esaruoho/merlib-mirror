#include <stdio.h>
#define SIZE 5
#define CRITSIZE 7

int
testone(int s[SIZE][SIZE],int a, int b)
{
	int             t[SIZE+1];
	int             that;
	int             i;
	int             goodflag = 0;
	for (i = 1; i <= SIZE; i++)
		t[i] = 0;
	for (i = 0; i < SIZE; i++)
		t[s[a][i]] = t[s[i][b]] = 1; /* set both to 1 */
	for (i = 1; i <= SIZE; i++)
		if (t[i])
			goodflag++;
		else
			that = i;
	if (goodflag == SIZE - 1)
	{
		s[a][b] = that;
		return 1;
	}
	else
		return 0;
}

void
print(int s[SIZE][SIZE])
{
	int             a, b;
	for (a = 0; a < SIZE; a++) 
	{
		for (b = 0; b < SIZE; b++) 
		{
			printf("%d", s[a][b]);
		} 
		printf(" ");
	} 
	printf("\n");
}

int fill(int s[SIZE][SIZE])
{
		int a,b,changed,mod=1,flag=0;

		while (mod) {
			/* go through each element in the latin square */
			/* and test whether that element has a forced */
			/* completion. */
			mod = 0;
			for (a = 0; a < SIZE; a++) {
				for (b = 0; b < SIZE; b++) {
					if (!s[a][b])
					{
						changed=testone(s, a, b);
						flag += changed;
						if (!mod && changed)
							mod = 1;
					}
			}
		}
	}
	return (flag==SIZE*SIZE-CRITSIZE);
}

int
main()
{
	int             a, b;
	/* 1.1.1 */ 
	int s1[5][5]={{1,2,3,4,5},{2,1,4,5,3},{3,5,1,2,4},{4,3,5,1,2},{5,4,2,3,1}};
	int j[CRITSIZE],x[CRITSIZE],y[CRITSIZE], s[SIZE][SIZE], u[SIZE][SIZE];

	for (j[6] = 0     ; j[6] <= SIZE*SIZE-7; j[6]++)
	for (j[5] = j[6]+1; j[5] <= SIZE*SIZE-6; j[5]++)
	for (j[4] = j[5]+1; j[4] <= SIZE*SIZE-5; j[4]++)
	for (j[3] = j[4]+1; j[3] <= SIZE*SIZE-4; j[3]++)
	for (j[2] = j[3]+1; j[2] <= SIZE*SIZE-3; j[2]++)
	for (j[1] = j[2]+1; j[1] <= SIZE*SIZE-2; j[1]++)
	for (j[0] = j[1]+1; j[0] <= SIZE*SIZE-1; j[0]++) 
	{
		/* fill the latin square with zeros */

		for (a = 0; a < SIZE; a++) {
			for (b = 0; b < SIZE; b++) {
				s[a][b] = u[a][b] = 0;
			}
		}

		/* put the relevant entries in */	

		for (a = 0; a<CRITSIZE; a++)
		{
			x[a] = j[a]%SIZE;  y[a] = j[a]/SIZE;
			u[y[a]][x[a]]=s[y[a]][x[a]]=s1[y[a]][x[a]];
		}

		/*
		 * go through the latin square to guess 
		 * the values of certain squares
		 */

		if (fill(s)) print(u);
	}
}
