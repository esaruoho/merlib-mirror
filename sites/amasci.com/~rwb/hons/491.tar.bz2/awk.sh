awk '{if (length == 6) {print("\\hline",substr($1,1,1),"&",substr($1,2,1)),"&",substr($1,3,1),"&",substr($1,4,1),"&",substr($1,5,1),"&",substr($1,6,1),"\\\\"} else {print $0}}' ap > ap2.txt
