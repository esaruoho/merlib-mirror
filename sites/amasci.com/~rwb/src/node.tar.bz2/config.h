#define HAVE_STDIO_H 1
#define HAVE_UNISTD_H 1
#define HAVE_STDLIB_H 1
#define HAVE_TIME_H 1
#define HAVE_ERRNO_H 1
#define HAVE_SYS_TIME_H 1
