/* node counter by Richard Bean, 27 May 2002 */
/* special enpassant stuff */

#include <stdio.h>
#include <stdlib.h>
#include "tree.h"

int wanted, cut = 0, dup = 0, opt = 0;
unsigned long long ran[64][13];
FILE *f,*in,*out;
int counts[10000];
 int qc;

struct pos
{
  long rank[8];
  unsigned char epc;			/* ep, castle */
  char depth;
  int count;
};

struct pos2
{
  int pos[8][8];
  char ep;
  char castle;
  int count;
};

typedef struct pos2 POS2;
typedef struct pos POS;

tree *postree;
int CompPos (POS * p1, POS * p2);

long long king (int pos[8][8], int depth, int k, int i, int j, char castle);
long long pawn (int pos[8][8], int depth, int s, int i, int j, char ep,
		char castle);
int legal (int pos[8][8], int sidetomove);
long long rook (int pos[8][8], int depth, int s, int i, int j, char castle);
long long knight (int pos[8][8], int depth, int s, int i, int j, char castle);
long long bishop (int pos[8][8], int depth, int s, int i, int j, char castle);
void printpos (int pos[8][8], int sidetomove, int depth);
int pawnch (int x, int y, int i, int j, int s);
int knightch (int x, int y, int i, int j);
int bishopch (int pos[8][8], int x, int y, int i, int j);
int rookch (int pos[8][8], int x, int y, int i, int j);
int kingch (int x, int y, int i, int j);
void setpos (POS * p, int pos[8][8], char ep, char castle, char depth);
POS2 getpos (POS * p);
unsigned int Random32 (void);
unsigned long long Random64 (void);
char updatecastle (int pos[8][8], int s, char castle);
int tree_disp (tree ** ppr_tree);
void readpos(POS *p, FILE *f);
void writepos(POS *p, FILE *f);

long long
generate (int pos[8][8], int depth, int sidetomove, char ep, char castle)
{
  /* generate all legal moves in the pos */
  /* if pos is checkmate there are no legal moves */
  int i, j;
  long long tot = 0;
  depth++;
  sidetomove = (sidetomove > 0) ? 1 : -1;
  castle = updatecastle (pos, sidetomove, castle);
  if (depth == wanted)
    {
      POS *samep, p;
      unsigned long long g = 0;
      dup++;
      for (i = 0; i < 8; i++)
	for (j = 0; j < 8; j++)
	  g += ran[(i << 3) + j][pos[i][j] + 6];
      g &= 3;

      /* if (samep) {samep->count++;return 1;}
      else
      {
	  POS *p = (POS *) malloc (sizeof (POS));
          dup++;
	  setpos (p, pos, ep, castle, (char)depth);
          p->count=0; 
          writepos(p,out);
	  tree_add (&postree, CompPos, p, free);
      } */

      if ((int)g==opt) 
      {
	setpos (&p, pos, ep, castle, (char) depth);
	samep = (POS *) tree_srch (&postree, CompPos, &p);
	if (samep)
	  {
	    (samep->count)+=qc;
	    return 1;
	  }
	else
	  {
	    POS *p = (POS *) malloc (sizeof (POS));
	    p->count = qc;
	    setpos (p, pos, ep, castle, (char) depth);
	    tree_add (&postree, CompPos, p, free);
	  }
      }
      return 1;
    }
  /*if (depth == 1) printpos(pos,sidetomove,depth); */
  for (i = 0; i < 8; i++)
    for (j = 0; j < 8; j++)
      {
	/*if (!pos[i][j]) continue; */
	if (sidetomove < 0)
	  {
	    if (pos[i][j] < 0)
	      switch (pos[i][j])
		{
		case -1:
		  tot += pawn (pos, depth, pos[i][j], i, j, ep, castle);
		  break;
		case -2:
		  tot += king (pos, depth, pos[i][j], i, j, castle);
		  break;
		case -3:
		  tot += knight (pos, depth, pos[i][j], i, j, castle);
		  break;
		case -4:
		  tot += bishop (pos, depth, pos[i][j], i, j, castle);
		  break;
		case -5:
		  tot += rook (pos, depth, pos[i][j], i, j, castle);
		  break;
		case -6:
		  {
		    tot += bishop (pos, depth, pos[i][j], i, j, castle);
		    tot += rook (pos, depth, pos[i][j], i, j, castle);
		    break;
		  }
		}
	  }
	else
	  {
	    if (pos[i][j] > 0)
	      switch (pos[i][j])
		{
		case 1:
		  tot += pawn (pos, depth, pos[i][j], i, j, ep, castle);
		  break;
		case 2:
		  tot += king (pos, depth, pos[i][j], i, j, castle);
		  break;
		case 3:
		  tot += knight (pos, depth, pos[i][j], i, j, castle);
		  break;
		case 4:
		  tot += bishop (pos, depth, pos[i][j], i, j, castle);
		  break;
		case 5:
		  tot += rook (pos, depth, pos[i][j], i, j, castle);
		  break;
		case 6:
		  {
		    tot += bishop (pos, depth, pos[i][j], i, j, castle);
		    tot += rook (pos, depth, pos[i][j], i, j, castle);
		    break;
		  }
		}
	  }
      }
  return tot;
}

long long
king (int pos[8][8], int depth, int k, int i, int j, char castle)
{
  /* normal king moves */
  int stm, x, y, c;
  long long tot = 0;
  stm = (k > 0) ? 5 : -5;
  if (k > 0)
    c = castle & 3;
  else
    c = castle & 12;
  for (x = -1; x <= 1; x++)
    for (y = -1; y <= 1; y++)
      {
	if (x || y)
	  {
	    int tmp = pos[i + x][j + y];
	    if (i + x >= 0 && i + x <= 7 && j + y >= 0 && j + y <= 7
		&& ((pos[i + x][j + y] <= 0 && k >= 0)
		    || (pos[i + x][j + y] >= 0 && k <= 0)))
	      {
		pos[i][j] = 0;
		pos[i + x][j + y] = k;
		if (legal (pos, k))
		  /* is current side in check after move? */
		  tot += generate (pos, depth, -k, 0, c);
		pos[i + x][j + y] = tmp;
		pos[i][j] = k;
	      }
	  }
      }
  if (legal (pos, k))		/* if current side not in check, consider castling */
    {
      /* queen side castling */
      if (((castle & 1) && (k < 0)) || ((castle & 4) && (k > 0)))
	/* i.e. we have a king on e1 or e8 & rook on a1 or a8 - j = 1 or 8 */
	{
	  /* white/black to move, nothing on b1/b8, c1/c8, d1/d8 */
	  if (pos[1][j] == 0 && pos[2][j] == 0 && pos[3][j] == 0)
	    {
	      pos[4][j] = 0;
	      pos[3][j] = k;	/* shuffle king one left */
	      /* is the pos legal with the king on d1/d8? */
	      if (legal (pos, k))
		{
		  pos[3][j] = 0;
		  pos[2][j] = k;	/* shuffle king one left */
		  /* legal with king on c1/c8? */
		  if (legal (pos, k))
		    {
		      pos[0][j] = 0;
		      pos[3][j] = stm;	/* rook */
		      tot += generate (pos, depth, -stm, 0, c);
		      pos[0][j] = stm;	/* put rook back */
		    }
		  pos[2][j] = 0;
		}
	      pos[4][j] = k;
	      pos[3][j] = 0;
	    }
	}
      /* king side castling */
      if (((castle & 2) && (k < 0)) || ((castle & 8) && (k > 0)))
	/* i.e. we have a king on e1 or e8 & rook on h1 or h8 - j = 1 or 8 */
	{
	  /* white/black to move, nothing on f1/f8, g1/g8 */
	  if (pos[5][j] == 0 && pos[6][j] == 0)
	    {
	      pos[4][j] = 0;
	      pos[5][j] = k;
	      /* is the pos legal with the king on f1/f8? */
	      if (legal (pos, k))
		{
		  pos[5][j] = 0;
		  pos[6][j] = k;
		  if (legal (pos, k))
		    {
		      pos[7][j] = 0;
		      pos[5][j] = stm;	/* rook on f1/f8 */
		      tot += generate (pos, depth, -stm, 0, c);
		      pos[7][j] = stm;	/* put rook back */
		    }
		  pos[6][j] = 0;
		}
	      pos[4][j] = k;	/* king back on e1/e8 */
	      pos[5][j] = 0;	/* clear f1/f8 */
	    }
	}
    }
  return tot;
}

long long
pawn (int pos[8][8], int depth, int s, int i, int j, char ep, char castle)
{
  long long tot = 0;
  if (((j < 6 && s > 0) || (j > 1 && s < 0)) && pos[i][j + s] == 0)
    /* empty square in front, and this square is not the back rank */
    {
      pos[i][j] = 0;
      pos[i][j + s] = s;
      if (legal (pos, s))
	tot += generate (pos, depth, -s, 0, castle);
      pos[i][j + s] = 0;
      pos[i][j] = s;
    }
  if (((s > 0 && j == 1) || (s < 0 && j == 6)) && pos[i][j + s + s] == 0
      && pos[i][j + s] == 0)
    /* two forward for white or black - be sure nothing in the way! */
    {
      pos[i][j] = 0;
      pos[i][j + s + s] = s;
      if (legal (pos, s))
	{
	  if ((i > 0 && pos[i - 1][j + s + s] == -s)
	      || (i < 7 && pos[i + 1][j + s + s] == -s))
	    {
	      /* but if it's not legal for the other side to move the pawn,
	         don't pass the ep flag anyway */
	      int l = 0;	/* assume !legal */
	      if (i > 0 && pos[i - 1][j + s + s] == -s)
		{
		  pos[i - 1][j + s + s] = 0;
		  pos[i][j + s + s] = 0;
		  pos[i][j + s] = -s;
		  if (legal (pos, -s))
		    l = 1;
		  pos[i - 1][j + s + s] = -s;
		  pos[i][j + s + s] = s;
		  pos[i][j + s] = 0;
		}
	      if (i < 7 && pos[i + 1][j + s + s] == -s)
		{
		  pos[i + 1][j + s + s] = 0;
		  pos[i][j + s + s] = 0;
		  pos[i][j + s] = -s;
		  if (legal (pos, -s))
		    l = 1;
		  pos[i + 1][j + s + s] = -s;
		  pos[i][j + s + s] = s;
		  pos[i][j + s] = 0;
		}
	      if (l == 1)
		tot += generate (pos, depth, -s, i + 1, castle);
	      else
		tot += generate (pos, depth, -s, 0, castle);
	    }
	  else
	    tot += generate (pos, depth, -s, 0, castle);
	}
      pos[i][j + s + s] = 0;
      pos[i][j] = s;
    }
  if (i > 0 && ((j < 6 && s > 0) || (j > 1 && s < 0))
      && ((pos[i - 1][j + s] < 0 && s > 0)
	  || (pos[i - 1][j + s] > 0 && s < 0)))
    /* capture left for W, right for B, no promotion */
    {
      int tmp = pos[i - 1][j + s];
      pos[i][j] = 0;
      pos[i - 1][j + s] = s;
      if (legal (pos, s))
	tot += generate (pos, depth, -s, 0, castle);
      pos[i - 1][j + s] = tmp;
      pos[i][j] = s;
    }
  if (i < 7 && ((j < 6 && s > 0) || (j > 1 && s < 0))
      && ((pos[i + 1][j + s] > 0 && s < 0)
	  || (pos[i + 1][j + s] < 0 && s > 0)))
    /* capture left for B, right for W, no promotion */
    {
      int tmp = pos[i + 1][j + s];
      pos[i][j] = 0;
      pos[i + 1][j + s] = s;
      if (legal (pos, s))
	tot += generate (pos, depth, -s, 0, castle);
      pos[i + 1][j + s] = tmp;
      pos[i][j] = s;
    }
  if (((j == 6 && s > 0) || (j == 1 && s < 0)) && pos[i][j + s] == 0)
    /* promoting straight ahead */
    {
      pos[i][j] = 0;
      if (legal (pos, s))	/* if legal w/o pawn, continue */
	{
	  pos[i][j + s] = s + s + s;	/* knight */
	  tot += generate (pos, depth, -s, 0, castle);
	  pos[i][j + s] += s;	/* bishop */
	  tot += generate (pos, depth, -s, 0, castle);
	  pos[i][j + s] += s;	/* rook */
	  tot += generate (pos, depth, -s, 0, castle);
	  pos[i][j + s] += s;	/* queen */
	  tot += generate (pos, depth, -s, 0, castle);
	  pos[i][j + s] = 0;
	}
      pos[i][j] = s;
    }
  if (((j == 6 && s > 0) || (j == 1 && s < 0))
      && ((pos[i - 1][j + s] < 0 && s > 0)
	  || (pos[i - 1][j + s] > 0 && s < 0)))
    /* promoting by capturing left for W, right for B */
    {
      int tmp = pos[i - 1][j + s];
      pos[i][j] = 0;
      pos[i - 1][j + s] = s + s + s;
      if (legal (pos, s))	/* if legal when "pawning" pawn, continue */
	{
	  //pos[i - 1][j + s] += s +s+ s;       /* knight */
	  tot += generate (pos, depth, -s, 0, castle);
	  pos[i - 1][j + s] += s;	/* bishop */
	  tot += generate (pos, depth, -s, 0, castle);
	  pos[i - 1][j + s] += s;	/* rook */
	  tot += generate (pos, depth, -s, 0, castle);
	  pos[i - 1][j + s] += s;	/* queen */
	  tot += generate (pos, depth, -s, 0, castle);
	}
      pos[i - 1][j + s] = tmp;
      pos[i][j] = s;
    }
  if (((j == 6 && s > 0) || (j == 1 && s < 0))
      && ((pos[i + 1][j + s] < 0 && s > 0)
	  || (pos[i + 1][j + s] > 0 && s < 0)))
    /* promoting by capturing right for W, left for B */
    {
      int tmp = pos[i + 1][j + s];
      pos[i][j] = 0;
      pos[i + 1][j + s] = s + s + s;
      if (legal (pos, s))	/* if legal when "pawning" pawn, continue */
	{
	  //pos[i + 1][j + s] = 3 * s;  /* knight */
	  tot += generate (pos, depth, -s, 0, castle);
	  pos[i + 1][j + s] += s;	/* bishop */
	  tot += generate (pos, depth, -s, 0, castle);
	  pos[i + 1][j + s] += s;	/* rook */
	  tot += generate (pos, depth, -s, 0, castle);
	  pos[i + 1][j + s] += s;	/* queen */
	  tot += generate (pos, depth, -s, 0, castle);
	}
      pos[i + 1][j + s] = tmp;
      pos[i][j] = s;
    }
#ifndef NOEP
  if (ep && (ep - i == 2 || i == ep)
      && ((s > 0 && j == 4) || (s < 0 && j == 3)))
    /* ep capture */
    {
      ep -= 1;
      pos[i][j] = 0;
      pos[ep][j + s] = s;
      pos[ep][j] = 0;
      if (legal (pos, s))
	tot += generate (pos, depth, -s, 0, castle);
      pos[ep][j] = -s;
      pos[ep][j + s] = 0;
      pos[i][j] = s;
    }
#endif
  return tot;
}

long long
knight (int pos[8][8], int depth, int s, int i, int j, char castle)
{
  int x, y;
  long long tot = 0;
  for (x = -1; x <= 1; x++)
    for (y = -1; y <= 1; y++)
      {
	if (x && y)
	  {
	    if (i + x + x >= 0 && i + x + x <= 7 && j + y >= 0 && j + y <= 7
		&& ((pos[i + x + x][j + y] <= 0 && s >= 0)
		    || (pos[i + x + x][j + y] >= 0 && s <= 0)))
	      {
		int tmp = pos[i + x + x][j + y];
		pos[i][j] = 0;
		pos[i + x + x][j + y] = s;
		if (legal (pos, s))
		  tot += generate (pos, depth, -s, 0, castle);
		pos[i + x + x][j + y] = tmp;
		pos[i][j] = s;
	      }
	    if (i + x >= 0 && i + x <= 7 && j + y + y >= 0 && j + y + y <= 7
		&& ((pos[i + x][j + y + y] <= 0 && s >= 0)
		    || (pos[i + x][j + y + y] >= 0 && s <= 0)))

	      {
		int tmp = pos[i + x][j + y + y];
		pos[i][j] = 0;
		pos[i + x][j + y + y] = s;
		if (legal (pos, s))
		  tot += generate (pos, depth, -s, 0, castle);
		pos[i + x][j + y + y] = tmp;
		pos[i][j] = s;
	      }
	  }
      }
  return tot;
}

long long
bishop (int pos[8][8], int depth, int s, int i, int j, char castle)
{
  int x, a = 1, b = 1, c = 1, d = 1;	/* a for +-, b for -+, c for ++, d for -- */
  long long tot = 0;
  for (x = 1; x <= 7; x++)
    {
      if (a && i + x >= 0 && i + x <= 7 && j - x >= 0 && j - x <= 7)
	{
	  int tmp = pos[i + x][j - x];
	  if (tmp)
	    a = 0;
	  if ((tmp <= 0 && s >= 0) || (tmp >= 0 && s <= 0))
	    {
	      pos[i][j] = 0;
	      pos[i + x][j - x] = s;
	      if (legal (pos, s))
		tot += generate (pos, depth, -s, 0, castle);
	      pos[i + x][j - x] = tmp;
	      pos[i][j] = s;
	    }
	}
      if (b && i >= x && i - x <= 7 && j + x >= 0 && j + x <= 7)
	{
	  int tmp = pos[i - x][j + x];
	  if (tmp)
	    b = 0;
	  if ((tmp <= 0 && s >= 0) || (tmp >= 0 && s <= 0))
	    {
	      pos[i][j] = 0;
	      pos[i - x][j + x] = s;
	      if (legal (pos, s))
		tot += generate (pos, depth, -s, 0, castle);
	      pos[i - x][j + x] = tmp;
	      pos[i][j] = s;
	    }
	}
      if (c && i + x >= 0 && i + x <= 7 && j + x >= 0 && j + x <= 7)
	{
	  int tmp = pos[i + x][j + x];
	  if (tmp)
	    c = 0;
	  if ((tmp <= 0 && s >= 0) || (tmp >= 0 && s <= 0))
	    {
	      pos[i][j] = 0;
	      pos[i + x][j + x] = s;
	      if (legal (pos, s))
		tot += generate (pos, depth, -s, 0, castle);
	      pos[i + x][j + x] = tmp;
	      pos[i][j] = s;
	    }
	}
      if (d && i >= x && i - x <= 7 && j - x >= 0 && j - x <= 7)
	{
	  int tmp = pos[i - x][j - x];
	  if (tmp)
	    d = 0;
	  if ((tmp <= 0 && s >= 0) || (tmp >= 0 && s <= 0))
	    {
	      pos[i][j] = 0;
	      pos[i - x][j - x] = s;
	      if (legal (pos, s))
		tot += generate (pos, depth, -s, 0, castle);
	      pos[i - x][j - x] = tmp;
	      pos[i][j] = s;
	    }
	}
    }
  return tot;
}

long long
rook (int pos[8][8], int depth, int s, int i, int j, char castle)
{
  int x, a = 1, b = 1, c = 1, d = 1;	/* a for + horiz, b for - horiz, c for + vertical, d for - vertical */
  long long tot = 0;
  for (x = 1; x <= 7; x++)
    {
      if (a && i + x >= 0 && i + x <= 7)
	{
	  int tmp = pos[i + x][j];
	  if (tmp)
	    a = 0;
	  if ((tmp <= 0 && s >= 0) || (tmp >= 0 && s <= 0))
	    {
	      pos[i][j] = 0;
	      pos[i + x][j] = s;
	      if (legal (pos, s))
		tot += generate (pos, depth, -s, 0, castle);
	      pos[i + x][j] = tmp;
	      pos[i][j] = s;
	    }
	}
      if (b && i >= x && i - x <= 7)
	{
	  int tmp = pos[i - x][j];
	  if (tmp)
	    b = 0;
	  if ((tmp <= 0 && s >= 0) || (tmp >= 0 && s <= 0))
	    {
	      pos[i][j] = 0;
	      pos[i - x][j] = s;
	      if (legal (pos, s))
		tot += generate (pos, depth, -s, 0, castle);
	      pos[i - x][j] = tmp;
	      pos[i][j] = s;
	    }
	}
      if (c && j + x >= 0 && j + x <= 7)
	{
	  int tmp = pos[i][j + x];
	  if (tmp)
	    c = 0;
	  if ((tmp <= 0 && s >= 0) || (tmp >= 0 && s <= 0))
	    {
	      pos[i][j] = 0;
	      pos[i][j + x] = s;
	      if (legal (pos, s))
		tot += generate (pos, depth, -s, 0, castle);
	      pos[i][j + x] = tmp;
	      pos[i][j] = s;
	    }
	}
      if (d && j >= x && j - x <= 7)
	{
	  int tmp = pos[i][j - x];
	  if (tmp)
	    d = 0;
	  if ((tmp <= 0 && s >= 0) || (tmp >= 0 && s <= 0))
	    {
	      pos[i][j] = 0;
	      pos[i][j - x] = s;
	      if (legal (pos, s))
		tot += generate (pos, depth, -s, 0, castle);
	      pos[i][j - x] = tmp;
	      pos[i][j] = s;
	    }
	}
    }
  return tot;
}

int
pawnch (int x, int y, int i, int j, int s)
{
  return (i - x == 1 || x - i == 1) && j - s == y;
}

int
knightch (int x, int y, int i, int j)
{
  return (x - i == -1 && y - j == -2) || (x - i == -1 && y - j == 2)
    || (x - i == 1 && y - j == 2) || (x - i == 1 && y - j == -2)
    || (x - i == -2 && y - j == -1) || (x - i == -2 && y - j == 1)
    || (x - i == 2 && y - j == 1) || (x - i == 2 && y - j == -1);
}


int
bishopch (int pos[8][8], int x, int y, int i, int j)
{
  if (x + j == y + i || x + y == i + j)
    {
      int c, e;
      if (x > i)
	{
	  e = x - i;
	  if (y > j)
	    {
	      for (c = 1; c < e; c++)
		if (i + c >= 0 && i + c <= 7 && j + c >= 0 && j + c <= 7
		    && pos[i + c][j + c])
		  return 0;
	    }
	  else
	    {
	      for (c = 1; c < e; c++)
		if (i + c >= 0 && i + c <= 7 && j >= c && j - c <= 7
		    && pos[i + c][j - c])
		  return 0;
	    }
	}
      else
	{
	  e = i - x;
	  if (y > j)
	    {
	      for (c = 1; c < e; c++)
		if (i >= c && i - c <= 7 && j + c >= 0 && j + c <= 7
		    && pos[i - c][j + c])
		  return 0;
	    }
	  else
	    {
	      for (c = 1; c < e; c++)
		if (i >= c && i - c <= 7 && j >= c && j - c <= 7
		    && pos[i - c][j - c])
		  return 0;
	    }
	}
      return 1;
    }
  return 0;
}

int
rookch (int pos[8][8], int x, int y, int i, int j)
{
  if (j == y)
    {
      int c, e;
      if (x > i)
	{
	  e = x - i;
	  for (c = 1; c < e; c++)
	    if (i + c >= 0 && i + c <= 7 && pos[i + c][j])
	      return 0;
	}
      else
	{
	  e = i - x;
	  for (c = 1; c < e; c++)
	    if (i >= c && i - c <= 7 && pos[i - c][j])
	      return 0;
	}
      return 1;
    }
  if (i == x)
    {
      int c, e;
      if (y > j)
	{
	  e = y - j;
	  for (c = 1; c < e; c++)
	    if (j + c >= 0 && j + c <= 7 && pos[i][j + c])
	      return 0;
	}
      else
	{
	  e = j - y;
	  for (c = 1; c < e; c++)
	    if (j >= c && j - c <= 7 && pos[i][j - c])
	      return 0;
	}
      return 1;
    }
  return 0;
}

int
kingch (int x, int y, int i, int j)
{
  return (x == i || x - 1 == i || x + 1 == i) && (y == j || y - 1 == j
						  || y + 1 == j);
}

int
legal (int pos[8][8], int sidetomove)
{
  /* if sidetomove is in check, return 0 - this isn't a legal pos */
  /* first, make sure we are not in check from an enemy knight */
  int i, j, s, x = -1, y = -1, ourking;
  s = (sidetomove > 0) ? 1 : -1;
  ourking = s + s;
  /* find our king */
  for (i = 0; i < 8 && x == -1; i++)
    for (j = 0; j < 8 && y == -1; j++)
      {
	if (pos[i][j] == ourking)
	  {
	    x = i;
	    y = j;
	  }
      }
  for (i = 0; i < 8; i++)
    for (j = 0; j < 8; j++)
      {
	//if (!pos[i][j]) continue; 
	if (sidetomove < 0)
	  {
	    switch (pos[i][j])
	      {
	      case 1:
		if (pawnch (x, y, i, j, s))
		  return 0;
		break;
	      case 2:
		if (kingch (x, y, i, j))
		  return 0;
		break;
	      case 3:
		if (knightch (x, y, i, j))
		  return 0;
		break;
	      case 4:
		if (bishopch (pos, x, y, i, j))
		  return 0;
		break;
	      case 5:
		if (rookch (pos, x, y, i, j))
		  return 0;
		break;
	      case 6:
		if (bishopch (pos, x, y, i, j) || rookch (pos, x, y, i, j))
		  return 0;
	      }
	  }
	else
	  {
	    switch (pos[i][j])
	      {
	      case -1:
		if (pawnch (x, y, i, j, s))
		  return 0;
		break;
	      case -2:
		if (kingch (x, y, i, j))
		  return 0;
		break;
	      case -3:
		if (knightch (x, y, i, j))
		  return 0;
		break;
	      case -4:
		if (bishopch (pos, x, y, i, j))
		  return 0;
		break;
	      case -5:
		if (rookch (pos, x, y, i, j))
		  return 0;
		break;
	      case -6:
		if (bishopch (pos, x, y, i, j) || rookch (pos, x, y, i, j))
		  return 0;
	      }
	  }
      }
  return 1;
}


void
printpos (int pos[8][8], int sidetomove, int depth)
{
  char s[13] =
    { 'q', 'r', 'b', 'n', 'k', 'p', '-', 'P', 'K', 'N', 'B', 'R', 'Q' };
  int i, j;
  for (j = 7; j >= 0; j--)
    {
      for (i = 0; i < 8; i++)
	{
	  putchar (s[pos[i][j] + 6]);
	}
      putchar ('\n');
    }
  putchar ('\n');
}


int
CompPos (POS * p1, POS * p2)
{
  int i;

  for (i = 0; i < 8; i++)
    {
      if (p1->rank[i] < p2->rank[i])
	return -1;
      if (p1->rank[i] > p2->rank[i])
	return 1;
    }
  if (p1->epc > p2->epc)
    return 1;
  if (p1->epc < p2->epc)
    return -1;
  return (0);
}

void
setpos (POS * p, int pos[8][8], char ep, char castle, char depth)
{
  int i, j;
  for (i = 0; i < 8; i++)
    {
      p->rank[i] = 0;
      for (j = 0; j < 8; j++)
	p->rank[i] += (pos[i][j] + 7) << (j << 2);
    }
  p->epc =  (ep << 4) + castle;
  p->depth = depth;
}

unsigned int
Random32 (void)
{
  /*
     random numbers from Mathematica 2.0.
     SeedRandom = 1;
     Table[Random[Integer, {0, 2^32 - 1}]
   */
  static const unsigned long x[55] = {
    1410651636UL, 3012776752UL, 3497475623UL, 2892145026UL, 1571949714UL,
    3253082284UL, 3489895018UL, 387949491UL, 2597396737UL, 1981903553UL,
    3160251843UL, 129444464UL, 1851443344UL, 4156445905UL, 224604922UL,
    1455067070UL, 3953493484UL, 1460937157UL, 2528362617UL, 317430674UL,
    3229354360UL, 117491133UL, 832845075UL, 1961600170UL, 1321557429UL,
    747750121UL, 545747446UL, 810476036UL, 503334515UL, 4088144633UL,
    2824216555UL, 3738252341UL, 3493754131UL, 3672533954UL, 29494241UL,
    1180928407UL, 4213624418UL, 33062851UL, 3221315737UL, 1145213552UL,
    2957984897UL, 4078668503UL, 2262661702UL, 65478801UL, 2527208841UL,
    1960622036UL, 315685891UL, 1196037864UL, 804614524UL, 1421733266UL,
    2017105031UL, 3882325900UL, 810735053UL, 384606609UL, 2393861397UL
  };
  static int init = 1;
  static unsigned long y[55];
  static int j, k;
  unsigned long ul;

  if (init)
    {
      int i;

      init = 0;
      for (i = 0; i < 55; i++)
	y[i] = x[i];
      j = 24 - 1;
      k = 55 - 1;
    }

  ul = (y[k] += y[j]);
  if (--j < 0)
    j = 55 - 1;
  if (--k < 0)
    k = 55 - 1;
  return ((unsigned int) ul);
}

unsigned long long
Random64 (void)
{
  unsigned long long result;
  unsigned int r1, r2;

  r1 = Random32 ();
  r2 = Random32 ();
  result = r1 | (unsigned long long) r2 << 32;
  return (result);
}

char
updatecastle (int pos[8][8], int s, char castle)
{
  if (pos[0][7] >= 0)		/* if white/empty on a8 ... */
    castle &= 14;		/* ... black can't castle q-side */
  if (pos[0][0] <= 0)		/* if black/empty on a1 ... */
    castle &= 11;		/* white can't castle q-side */
  if (pos[7][7] >= 0)		/* if white/empty on h8 ... */
    castle &= 13;		/* black can't castle k-side */
  if (pos[7][0] <= 0)		/* if black/empty on h1 ... */
    castle &= 7;		/* white can't castle k-side */
  return castle;
}

int
tree_disp (tree ** ppr_tree)
{
  if (*ppr_tree)
    {
      //printf ("%d\n", ((POS *) ((**ppr_tree).data))->count);
      writepos((POS *) (**ppr_tree).data, out);
      //counts[((POS *) ((**ppr_tree).data))->count]++;
      /* if (((POS *) ((**ppr_tree).data))->count == 16)
	{
	  POS2 p2 = getpos ((POS *) (**ppr_tree).data);
	  printpos (p2.pos, 0, 0);
	} */
    }
  if (!*ppr_tree)
    return 1;
  if (!tree_disp (&(**ppr_tree).left))
    return 0;
  if (!(POS *) ((**ppr_tree).data))
    return 0;
  if (!tree_disp (&(**ppr_tree).right))
    return 0;
  return 1;
}




POS2
getpos (POS * p)
{
  int i, j;
  POS2 q;
  for (i = 0; i < 8; i++)
    {
      unsigned long x = p->rank[i];
      for (j = 0; j < 8; j++)
	{
	  q.pos[i][j] = (x & 15) - 7;
	  x >>= 4;
	}
    }
  q.ep = p->epc >> 4;
  //printf("qe %d\n",q.ep);
  q.castle = p->epc & 15;
  q.count = p->count;
  return q;
}


int
main (int argc, char **argv)
{

  POS p; POS2 q;
  long long tot = 0;
  int boardx[8][8] = {
    {5, 3, 4, 6, 2, 4, 3, 5},
    {1, 1, 1, 1, 1, 1, 1, 1},
    {0, 0, 0, 0, 0, 0, 0, 0},
    {0, 0, 0, 0, 0, 0, 0, 0},
    {0, 0, 0, 0, 0, 0, 0, 0},
    {0, 0, 0, 0, 0, 0, 0, 0},
    {-1, -1, -1, -1, -1, -1, -1, -1},
    {-5, -3, -4, -6, -2, -4, -3, -5}
  };
  int board[8][8];
  int i, j,x,tt=0;
  if (argc != 5)
    {
      printf ("usage: %s filein fileout depth opt\n", argv[0]);
      exit (1);
    }
  memset(counts,0,sizeof(counts));
  for (i = 0; i < 64; i++)
  for (j = 0; j < 13; j++)
     ran[i][j] = Random64();
  wanted = atoi (argv[3]); wanted++;
  opt = atoi(argv[4]);
  out = fopen(argv[2],"w");
  in = fopen(argv[1],"r");
  while (1)
  {
   int l;
  readpos(&p,in);
  if (feof(in)) break;
  tt++;
  q = getpos(&p);
  //printpos(q.pos,0,0);
  //printf(" x ep c %d %d %d\n",q.count,q.ep,q.castle);
  qc=q.count;
  l=generate (q.pos, 0, -1, q.ep, q.castle);
  tot += q.count * l;
  //printf("%d \n",tot);
  }
  fclose(in);
  tree_disp (&postree);
  fclose(out);
   /*for (i = 0; i < 10000; i++)
    if (counts[i]) printf("%d %d\n",i,counts[i]);*/

  printf ("%d %lld %d\n", dup,tot,tt);
  return 0;
}

void readpos(POS *p, FILE *f)
{
	fread(&(p->rank),4,8,f); 
	fread(&(p->epc),1,1,f); 
	fread(&(p->count),sizeof(int),1,f); 
        p->depth=0;
}

void writepos(POS *p, FILE *f)
{
	fwrite(&(p->rank),4,8,f);
	fwrite(&(p->epc),1,1,f);
	fwrite(&(p->count),sizeof(int),1,f);
}
