#include <stdio.h>

struct pos { long rank[8]; int epc; int count; };

typedef struct pos POS;

void writepos (POS * p, FILE * f);
void setpos (POS * p, int pos[8][8], char ep, char castle, int count);

main (int argc, char **argv)
{
  int board[8][8], castle, i = 0, j = 0,c;
  POS p;  
  char s[13] =
    { 'q', 'r', 'b', 'n', 'k', 'p', '-', 'P', 'K', 'N', 'B', 'R', 'Q' };
  FILE *f;
  if (argc != 3)
    {
      printf ("usage: %s file1 file2\n", argv[0]);
      return (1);
    }
  f = fopen (argv[1], "r");
  while (i < 8)
    {
      int k, x = 99;
      c = getc (f);
      if (c == ' ')
	break;
      if (c == '/')
	{
	  i++;
	  j = 0;
	  continue;
	}
      for (k = 0; k < 13; k++)
	if (s[k] == c)
	  x = k - 6;
      if (x != 99)
	{
	  fflush (stdout);
	  board[j][7 - i] = x;
	  j++;
	}
      else
	for (k = 0; k < c - '0'; k++)
	  {
	    board[j][7 - i] = 0;
	    j++;
	  }
    }
  getc (f);
  getc (f);
  while (1)
    {
      c = getc (f);
      if (c == ' ')
	break;
      if (c == 'k')
	castle |= 1;		/* BK */
      if (c == 'q')
	castle |= 2;		/* BQ */
      if (c == 'K')
	castle |= 8;		/* WK */
      if (c == 'Q')
	castle |= 4;		/* WQ */
    }
  fclose (f);
  setpos(&p,board,0,castle,1);
  f = fopen (argv[2], "wb");
  writepos(&p,f);
  fclose(f);
return 0;
}

void
setpos (POS * p, int pos[8][8], char ep, char castle, int count)
{
  int i, j;
  for (i = 0; i < 8; i++)
    {
      p->rank[i] = 0;
      for (j = 0; j < 8; j++)
	p->rank[i] += (pos[i][j] + 7) << (j << 2);
    }
  p->epc = (ep << 4) + castle;
  p->count = count;
}

void
writepos (POS * p, FILE * f)
{
  fwrite (&(p->rank), 4, 8, f);
  fwrite (&(p->epc), 1, 1, f);
  fwrite (&(p->count), sizeof (int), 1, f);
}
