/* node counter by Richard Bean, 27 May 2002 */
/* June 4,..,7 2002 - implementing 0x88 position */
/* June 10, 2002 - fixed */
//#define NOEP

/* 112 113 114 115 116 117 118 119 */
/*  96  97  98  99 100 101 102 103 */
/*  80  81  82  83  84  85  86  87 */
/*  64  65  66  67  68  69  70  71 */
/*  48  49  50  51  52  53  54  55 */
/*  32  33  34  35  36  37  38  39 */
/*  16  17  18  19  20  21  22  23 */
/*   0   1   2   3   4   5   6   7 */

/* detect when you are moving off the end of the board
   by ANDing with 0x88: legal iff (board & 0x88 == 0) */
/* rank number = position & 0x70; file number = position & 0x07 */

/* special enpassant stuff */

#include <stdio.h>
#include <stdlib.h>
#include "tree.h"
#include <errno.h>

int wanted, cut = 0, opt = 0, stm;
long long dup = 0;
unsigned long long ran[64][13];
int sq[64],qc;
FILE *out,*in;
struct pos2
{
  int pos[128];
  char ep;
  char castle;
  int count;
};

typedef struct pos2 POS2;


struct pos
{
  long rank[8];
  unsigned char epc;		/* ep, castle */
  int count;
};

typedef struct pos POS;
tree *postree;
int CompPos (POS * p1, POS * p2);
void readpos (POS * p, FILE * f);
void writepos (POS * p, FILE * f);
//void writepos ( long *rank, unsigned char *epc, int *count, FILE *f);
POS2 getpos (POS * p);

long long king (int pos[128], int depth, int k, int ij, char castle);
long long pawn (int pos[128], int depth, int s, int ij, char ep, char castle);
int legal (int pos[128], int sidetomove);
long long rook (int pos[128], int depth, int s, int ij, char castle);
long long knight (int pos[128], int depth, int s, int ij, char castle);
long long bishop (int pos[128], int depth, int s, int ij, char castle);
void printpos (int pos[128], int ep, int castle);
int pawnch (int xy, int ij, int s);
int knightch (int xy, int ij);
int bishopch (int pos[128], int xy, int ij);
int rookch (int pos[128], int xy, int ij);
int kingch (int xy, int ij);
void setpos (POS * p, int pos[128], char ep, char castle, int count);
unsigned int Random32 (void);
unsigned long long Random64 (void);
char updatecastle (int pos[128], int s, char castle);
int tree_disp (tree ** ppr_tree);

long long
generate (int pos[128], int depth, int sidetomove, char ep, char castle)
{
  /* generate all legal moves in the pos */
  /* if pos is checkmate there are no legal moves */
  int i;
  long long tot = 0;
  sidetomove = (sidetomove > 0) ? 1 : -1;
  castle = updatecastle (pos, sidetomove, castle);
  //printpos(pos,ep,castle);
  depth++;


  if (depth == wanted)
    {
      POS *samep, p;
      unsigned long long g = 0;
      //printpos(pos,ep,castle);
      dup++;
      for (i = 0; i < 64; i++)
	  g += ran[i][pos[sq[i]] + 6];
      //g %= 168;
      g = 0;

      /* if (samep) {samep->count++;return 1;}
      else
      {
	  POS *p = (POS *) malloc (sizeof (POS));
          dup++;
	  setpos (p, pos, ep, castle, 0);
          p->count=0; 
          writepos(p,out);
	  tree_add (&postree, CompPos, p, free);
      } */

      if ((int)g==opt) 
      {
	setpos (&p, pos, ep, castle, 0);
	samep = (POS *) tree_srch (&postree, CompPos, &p);
	if (samep)
	  {
	    (samep->count)+=qc;
	    return 1;
	  }
	else
	  {
	    POS *p = (POS *) malloc (sizeof (POS));
	    p->count = qc;
	    setpos (p, pos, ep, castle, qc);
	    tree_add (&postree, CompPos, p, free);
	  }
      }
      return 1;
    }

  for (i = 0; i < 64; i++)
    {
      if (sidetomove < 0)
	{
	  if (pos[sq[i]] < 0)
	    switch (pos[sq[i]])
	      {
	      case -1:
		tot += pawn (pos, depth, pos[sq[i]], sq[i], ep, castle);
		break;
	      case -2:
		tot += king (pos, depth, pos[sq[i]], sq[i], castle);
		break;
	      case -3:
		tot += knight (pos, depth, pos[sq[i]], sq[i], castle);
		break;
	      case -4:
		tot += bishop (pos, depth, pos[sq[i]], sq[i], castle);
		break;
	      case -5:
		tot += rook (pos, depth, pos[sq[i]], sq[i], castle);
		break;
	      case -6:
		{
		  tot += bishop (pos, depth, pos[sq[i]], sq[i], castle);
		  tot += rook (pos, depth, pos[sq[i]], sq[i], castle);
		  break;
		}
	      }
	}
      else
	{
	  if (pos[sq[i]] > 0)
	    switch (pos[sq[i]])
	      {
	      case 1:
		tot += pawn (pos, depth, pos[sq[i]], sq[i], ep, castle);
		break;
	      case 2:
		tot += king (pos, depth, pos[sq[i]], sq[i], castle);
		break;
	      case 3:
		tot += knight (pos, depth, pos[sq[i]], sq[i], castle);
		break;
	      case 4:
		tot += bishop (pos, depth, pos[sq[i]], sq[i], castle);
		break;
	      case 5:
		tot += rook (pos, depth, pos[sq[i]], sq[i], castle);
		break;
	      case 6:
		{
		  tot += bishop (pos, depth, pos[sq[i]], sq[i], castle);
		  tot += rook (pos, depth, pos[sq[i]], sq[i], castle);
		  break;
		}
	      }
	}
    }

  return tot;
}

long long
king (int pos[128], int depth, int k, int ij, char castle)
{
  /* normal king moves */
  /* (i,j) was old king position */
  /* ij is new king position, +/- 1, +/- 15,16,17 */
  int offsets[] = { -17, -16, -15, -1, 1, 15, 16, 17 };
  int stm, x, y, c;
  long long tot = 0;
  stm = (k > 0) ? 5 : -5;
  if (k > 0)
    c = castle & 3;
  else
    c = castle & 12;
  for (x = 0; x < 8; x++)
    {
      /* use offsets[] array */
      int new;
      new = offsets[x] + ij;
      if ((new & 0x88) == 0)
	{
	  int tmp = pos[new];
	  if ((tmp <= 0 && k >= 0) || (tmp >= 0 && k <= 0))
	    {
	      pos[ij] = 0;
	      pos[new] = k;
	      if (legal (pos, k))
		/* is current side in check after move? */
		tot += generate (pos, depth, -k, 0, c);
	      pos[new] = tmp;
	      pos[ij] = k;
	    }
	}
    }
  if (legal (pos, k))		/* if current side not in check, consider castling */
    {
      /* queen side castling */
      if (((castle & 1) && (k < 0)) || ((castle & 4) && (k > 0)))
	/* i.e. we have a king on e1 or e8 & rook on a1 or a8 - j = 1 or 8 */
	{
	  /* white/black to move, nothing on b1/b8, c1/c8, d1/d8 */
	  if (pos[ij - 1] == 0 && pos[ij - 2] == 0 && pos[ij - 3] == 0)
	    {
	      pos[ij] = 0;
	      pos[ij - 1] = k;	/* shuffle king one left */
	      /* is the pos legal with the king on d1/d8? */
	      if (legal (pos, k))
		{
		  pos[ij - 1] = 0;
		  pos[ij - 2] = k;	/* shuffle king one left */
		  /* legal with king on c1/c8? */
		  if (legal (pos, k))
		    {
		      pos[ij - 4] = 0;
		      pos[ij - 1] = stm;	/* rook */
		      tot += generate (pos, depth, -stm, 0, c);
		      pos[ij - 4] = stm;	/* put rook back */
		    }
		  pos[ij - 2] = 0;
		}
	      pos[ij] = k;
	      pos[ij - 1] = 0;
	    }
	}
      /* king side castling */
      if (((castle & 2) && (k < 0)) || ((castle & 8) && (k > 0)))
	/* i.e. we have a king on e1 or e8 & rook on h1 or h8 - j = 1 or 8 */
	{
	  /* white/black to move, nothing on f1/f8, g1/g8 */
	  if (pos[ij + 1] == 0 && pos[ij + 2] == 0)
	    {
	      pos[ij] = 0;
	      pos[ij + 1] = k;
	      /* is the pos legal with the king on f1/f8? */
	      if (legal (pos, k))
		{
		  pos[ij + 1] = 0;
		  pos[ij + 2] = k;
		  if (legal (pos, k))
		    {
		      pos[ij + 3] = 0;
		      pos[ij + 1] = stm;	/* rook on f1/f8 */
		      tot += generate (pos, depth, -stm, 0, c);
		      pos[ij + 3] = stm;	/* put rook back */
		    }
		  pos[ij + 2] = 0;
		}
	      pos[ij] = k;	/* king back on e1/e8 */
	      pos[ij + 1] = 0;	/* clear f1/f8 */
	    }
	}
    }
  return tot;
}

long long
pawn (int pos[128], int depth, int s, int ij, char ep, char castle)
{
  long long tot = 0;
  if (((ij < 96 && s > 0) || (ij > 24 && s < 0)) && pos[ij + (s << 4)] == 0)
    /* empty square in front, and this square is not the back rank */
    /* go forward one */
    {
      pos[ij] = 0;
      pos[ij + (s << 4)] = s;
      if (legal (pos, s))
	tot += generate (pos, depth, -s, 0, castle);
      pos[ij + (s << 4)] = 0;
      pos[ij] = s;
    }
  if (((s > 0 && ((ij & 0x70) >> 4) == 1)
       || (s < 0 && ((ij & 0x70) >> 4) == 6)) && pos[ij + (s << 5)] == 0
      && pos[ij + (s << 4)] == 0)
    /* two forward for white or black - be sure nothing in the way! */
    {
      pos[ij] = 0;
      pos[ij + (s << 5)] = s;
      if (legal (pos, s))
	{
	  if ((((ij & 0x07) > 0 && pos[ij - 1 + (s << 5)] == -s) ||
	       (ij & 0x07) < 7 && pos[ij + 1 + (s << 5)] == -s))
	    {
	      /* but if it's not legal for the other side to move the pawn,
	         don't pass the ep flag anyway */
	      int l = 0;	/* assume !legal */
	      if ((ij & 0x07) > 0 && pos[ij - 1 + (s << 5)] == -s)
		{
		  pos[ij - 1 + (s << 5)] = 0;
		  pos[ij + (s << 5)] = 0;
		  pos[ij + (s << 4)] = -s;
		  if (legal (pos, -s))
		    l = 1;
		  pos[ij - 1 + (s << 5)] = -s;
		  pos[ij + (s << 5)] = s;
		  pos[ij + (s << 4)] = 0;
		}
	      if ((ij & 0x07) < 7 && pos[ij + 1 + (s << 5)] == -s)
		{
		  pos[ij + 1 + (s << 5)] = 0;
		  pos[ij + (s << 5)] = 0;
		  pos[ij + (s << 4)] = -s;
		  if (legal (pos, -s))
		    l = 1;
		  pos[ij + 1 + (s << 5)] = -s;
		  pos[ij + (s << 5)] = s;
		  pos[ij + (s << 4)] = 0;
		}
	      if (l == 1)
		{		//printf("ep %d\n",ij+(s<<4));
		  tot += generate (pos, depth, -s, ij + (s << 4), castle);
		}
	      else
		tot += generate (pos, depth, -s, 0, castle);
	    }
	  else
	    tot += generate (pos, depth, -s, 0, castle);
	}
      pos[ij + (s << 5)] = 0;
      pos[ij] = s;
    }
  if ((ij & 0x07) > 0 && ((((ij & 0x70) >> 4) < 6 && s > 0)
			  || (((ij & 0x70) >> 4) > 1 && s < 0))
      && ((pos[ij - 1 + (s << 4)] < 0 && s > 0)
	  || (pos[ij - 1 + (s << 4)] > 0 && s < 0)))
    /* capture left for W, right for B, no promotion */
    {
      int tmp;
      tmp = pos[ij - 1 + (s << 4)];
      pos[ij] = 0;
      pos[ij - 1 + (s << 4)] = s;
      if (legal (pos, s))
	tot += generate (pos, depth, -s, 0, castle);
      pos[ij - 1 + (s << 4)] = tmp;
      pos[ij] = s;
    }
  if ((ij & 0x07) < 7 &&
      ((((ij & 0x70) >> 4) < 6 && s > 0) || (((ij & 0x70) >> 4) > 1 && s < 0))
      && ((pos[ij + 1 + (s << 4)] > 0 && s < 0)
	  || (pos[ij + 1 + (s << 4)] < 0 && s > 0)))
    /* capture left for B, right for W, no promotion */
    {
      int tmp = pos[ij + 1 + (s << 4)];
      pos[ij] = 0;
      pos[ij + 1 + (s << 4)] = s;
      if (legal (pos, s))
	tot += generate (pos, depth, -s, 0, castle);
      pos[ij + 1 + (s << 4)] = tmp;
      pos[ij] = s;
    }
  if ((((((ij & 0x70) >> 4) == 6 && s > 0)) ||
       (((ij & 0x70) >> 4) == 1 && s < 0)) && pos[ij + (s << 4)] == 0)
    /* promoting straight ahead */
    {
      pos[ij] = 0;
      if (legal (pos, s))	/* if legal w/o pawn, continue */
	{
	  pos[ij + (s << 4)] = s + s + s;	/* knight */
	  tot += generate (pos, depth, -s, 0, castle);
	  pos[ij + (s << 4)] += s;	/* bishop */
	  tot += generate (pos, depth, -s, 0, castle);
	  pos[ij + (s << 4)] += s;	/* rook */
	  tot += generate (pos, depth, -s, 0, castle);
	  pos[ij + (s << 4)] += s;	/* queen */
	  tot += generate (pos, depth, -s, 0, castle);
	  pos[ij + (s << 4)] = 0;
	}
      pos[ij] = s;
    }
  //printf("(ij & 0x70) << 4 %d\n",(ij & 0x70) << 4);
  if (((((((ij & 0x70) >> 4) == 6 && s > 0))
	|| (((ij & 0x70) >> 4) == 1 && s < 0)))
      && ((pos[ij - 1 + (s << 4)] < 0 && s > 0)
	  || (pos[ij - 1 + (s << 4)] > 0 && s < 0)))
    /* promoting by capturing left for W, right for B */
    {
      int tmp = pos[ij - 1 + (s << 4)];
      //printf("xop\n");
      pos[ij] = 0;
      pos[ij - 1 + (s << 4)] = s + s + s;
      if (legal (pos, s))	/* if legal when "pawning" pawn, continue */
	{
	  //pos[i - 1][j + s] += s +s+ s;       /* knight */
	  tot += generate (pos, depth, -s, 0, castle);
	  pos[ij - 1 + (s << 4)] += s;	/* bishop */
	  tot += generate (pos, depth, -s, 0, castle);
	  pos[ij - 1 + (s << 4)] += s;	/* rook */
	  tot += generate (pos, depth, -s, 0, castle);
	  pos[ij - 1 + (s << 4)] += s;	/* queen */
	  tot += generate (pos, depth, -s, 0, castle);
	}
      pos[ij - 1 + (s << 4)] = tmp;
      pos[ij] = s;
    }
  if (((((((ij & 0x70) >> 4) == 6 && s > 0))
	|| (((ij & 0x70) >> 4) == 1 && s < 0)))
      && ((pos[ij + 1 + (s << 4)] < 0 && s > 0)
	  || (pos[ij + 1 + (s << 4)] > 0 && s < 0)))
    /* promoting by capturing right for W, left for B */
    {
      int tmp = pos[ij + 1 + (s << 4)];
      pos[ij] = 0;
      pos[ij + 1 + (s << 4)] = s + s + s;
      if (legal (pos, s))	/* if legal when "pawning" pawn, continue */
	{
	  //pos[i + 1][j + s] = 3 * s;  /* knight */
	  tot += generate (pos, depth, -s, 0, castle);
	  pos[ij + 1 + (s << 4)] += s;	/* bishop */
	  tot += generate (pos, depth, -s, 0, castle);
	  pos[ij + 1 + (s << 4)] += s;	/* rook */
	  tot += generate (pos, depth, -s, 0, castle);
	  pos[ij + 1 + (s << 4)] += s;	/* queen */
	  tot += generate (pos, depth, -s, 0, castle);
	}
      pos[ij + 1 + (s << 4)] = tmp;
      pos[ij] = s;
    }
#ifndef NOEP
  if (ep && ((s > 0 && (ep - ij == 17 || ep - ij == 15)) ||
	     (s < 0 && (ep - ij == -17 || ep - ij == -15))))
    // && ((ep - (i&0x07)) == 2 || (i&0x07) == ep)
    // && ((s > 0 && ((ij&0x70)<<4) == 4) ||
    // (s < 0 && ((ij&0x70)<<4) == 3)))
    /* ep capture */
    {
      pos[ij] = 0;		/* remove the capturing pawn */
      pos[ep] = s;		/* place our pawn on the (empty) ep target square */
      pos[ep - (s << 4)] = 0;	/* the pawn which is being removed */
      if (legal (pos, s))
	tot += generate (pos, depth, -s, 0, castle);
      pos[ep] = 0;
      pos[ep - (s << 4)] = -s;
      pos[ij] = s;
    }
#endif
  return tot;
}


long long
knight (int pos[128], int depth, int s, int ij, char castle)
{
  int x, y;
  int offset[] = {
    -33, -31, -18, -14, 14, 18, 31, 33
  };
  long long tot = 0;
  for (x = 0; x < 8; x++)
    {
      int new = ij + offset[x];
      if (((new & 0x88) == 0)
	  && ((pos[new] <= 0 && s >= 0) || (pos[new] >= 0 && s <= 0)))
	{
	  int tmp = pos[new];
	  pos[ij] = 0;
	  pos[new] = s;
	  if (legal (pos, s))
	    tot += generate (pos, depth, -s, 0, castle);
	  pos[ij] = s;
	  pos[new] = tmp;
	}
    }
  pos[ij] = s;
  return tot;
}

long long
rook (int pos[128], int depth, int s, int ij, char castle)
{
  int x, y, a = 1, b = 1, c = 1, d = 1;	/* a for +-, b for -+, c for ++, d for -- */
  int new;
  int offset[] = {
    -16, -1, +1, +16
  };
  long long tot = 0;
  for (y = 0; y < 4; y++)
    {
      a = 1;
      new = ij;
      for (x = 1; x <= 7; x++)
	{
	  new += offset[y];
	  if (a && (new & 0x88) == 0)
	    {
	      int tmp = pos[new];
	      if (tmp)
		a = 0;		/* stop, there's a piece in the way */
	      if ((tmp <= 0 && s >= 0) || (tmp >= 0 && s <= 0))
		{
		  pos[ij] = 0;
		  pos[new] = s;
		  //printf("car\n");
		  //printpos(pos,0,0);
		  if (legal (pos, s))
		    tot += generate (pos, depth, -s, 0, castle);
		  pos[new] = tmp;
		  pos[ij] = s;
		}
	    }
	}
    }
  return tot;
}

long long
bishop (int pos[128], int depth, int s, int ij, char castle)
{
  int x, a = 1, b = 1, c = 1, d = 1;	/* a for +-, b for -+, c for ++, d for -- */
  int new, y;
  int offset[] = {
    -17, -15, +15, +17
  };
  long long tot = 0;
  for (y = 0; y < 4; y++)
    {
      a = 1;
      new = ij;
      for (x = 1; x <= 7; x++)
	{
	  new += offset[y];
	  if (a && (new & 0x88) == 0)
	    {
	      int tmp = pos[new];
	      if (tmp)
		a = 0;		/* stop, there's a piece in the way */
	      if ((tmp <= 0 && s >= 0) || (tmp >= 0 && s <= 0))
		{
		  pos[ij] = 0;
		  pos[new] = s;
		  if (legal (pos, s))
		    tot += generate (pos, depth, -s, 0, castle);
		  pos[new] = tmp;
		  pos[ij] = s;
		}
	    }
	}
    }
  return tot;
}

/* ij = xy + 15 so ij - xy = 15, xy - ij = -15 */
int
pawnch (int xy, int ij, int s)
{
  /* our king (s) is at xy and pawn at ij */
  //return (i - x == 1 || x - i == 1) && j - s == y;
  /* if our king is white, s == 1 and the black
     pawn (ij) is at xy+15 or xy+17, thus xy - ij = -15  */
  if (s > 0)
    return (xy - ij == -15) || (xy - ij == -17);
  else
    return (xy - ij == 15) || (xy - ij == 17);
}

int
knightch (int xy, int ij)
{
  /*return (x - i == -1 && y - j == -2) || (x - i == -1 && y - j == 2)
     || (x - i == 1 && y - j == 2) || (x - i == 1 && y - j == -2)
     || (x - i == -2 && y - j == -1) || (x - i == -2 && y - j == 1)
     || (x - i == 2 && y - j == 1) || (x - i == 2 && y - j == -1); */
  //printf ("%d %d\n", xy, ij);
  return (xy - ij == -33) || (xy - ij == -31) || (xy - ij == -18)
    || (xy - ij == -14) || (xy - ij == 14) || (xy - ij == 18) || (xy - ij
								  == 31)
    || (xy - ij == 33);
}


int
bishopch (int pos[128], int xy, int ij)
{
  int i;
  /* return 1 if in check */
  if (xy > ij)
    {
      if ((xy - ij) % 15 == 0)
	{
	  for (i = ij + 15; i < xy; i += 15)
	    if (pos[i])
	      return 0;
	  return 1;
	}
      if ((xy - ij) % 17 == 0)
	{
	  for (i = ij + 17; i < xy; i += 17)
	    if (pos[i])
	      return 0;
	  return 1;
	}
      return 0;
    }
  /* xy < ij */
  if ((ij - xy) % 15 == 0)
    {
      for (i = xy + 15; i < ij; i += 15)
	if (pos[i])
	  return 0;
      return 1;
    }
  if ((ij - xy) % 17 == 0)
    {
      for (i = xy + 17; i < ij; i += 17)
	if (pos[i])
	  return 0;
      return 1;
    }
  return 0;
}

int
rookch (int pos[128], int xy, int ij)
{
  int i;			//printf("xy %d ij %d\n",xy,ij);
  if ((xy & 0x07) == (ij & 0x07))	/* same file */
    {
      if (xy > ij)
	{
	  for (i = ij + 16; i < xy; i += 16)
	    if (pos[i])
	      return 0;
	  return 1;
	}
      else
	{
	  //printf("xy %d ij %d\n",xy,ij);
	  for (i = xy + 16; i < ij; i += 16)
	    if (pos[i])
	      return 0;
	  return 1;
	}
    }
  if ((xy & 0x70) == (ij & 0x70))	/* same rank */
    {
      if (xy > ij)
	{
	  for (i = ij + 1; i < xy; i += 1)
	    if (pos[i])
	      return 0;
	  return 1;
	}
      else
	{
	  for (i = xy + 1; i < ij; i += 1)
	    if (pos[i])
	      return 0;
	  return 1;
	}
    }
  return 0;
}

int
kingch (int xy, int ij)
{
  //return (x == i || x - 1 == i || x + 1 == i) && (y == j || y - 1 == j
  //                                              || y + 1 == j);
  return
    (xy - ij == -17) ||
    (xy - ij == -16) ||
    (xy - ij == -15) ||
    (xy - ij == -1) ||
    (xy - ij == 1) || (xy - ij == 15) || (xy - ij == 16) || (xy - ij == 17);
}

int
legal (int pos[128], int sidetomove)
{
  /* if sidetomove is in check, return 0 - this isn't a legal pos */
  /* first, make sure we are not in check from an enemy knight */
  int i, s, xy = -1, ourking;
  s = (sidetomove > 0) ? 1 : -1;
  ourking = s + s;
  /* find our king */
  for (i = 0; i < 64; i++)
    if (pos[sq[i]] == ourking)
      {
	xy = sq[i];
	break;
      }
  for (i = 0; i < 64; i++)
    {
      if (sidetomove < 0)
	{

	  switch (pos[sq[i]])
	    {
	    case 1:
	      if (pawnch (xy, sq[i], s))
		return 0;
	      break;
	    case 2:
	      if (kingch (xy, sq[i]))
		return 0;
	      break;
	    case 3:
	      if (knightch (xy, sq[i]))
		return 0;
	      break;
	    case 4:
	      if (bishopch (pos, xy, sq[i]))
		return 0;
	      break;
	    case 5:
	      if (rookch (pos, xy, sq[i]))
		return 0;
	      break;
	    case 6:
	      if (bishopch (pos, xy, sq[i]) || rookch (pos, xy, sq[i]))
		return 0;
	    }
	}
      else
	{
	  switch (pos[sq[i]])
	    {
	    case -1:
	      if (pawnch (xy, sq[i], s))
		return 0;
	      break;
	    case -2:
	      if (kingch (xy, sq[i]))
		return 0;
	      break;
	    case -3:
	      if (knightch (xy, sq[i]))
		return 0;
	      break;
	    case -4:
	      if (bishopch (pos, xy, sq[i]))
		return 0;
	      break;
	    case -5:
	      if (rookch (pos, xy, sq[i]))
		return 0;
	      break;
	    case -6:
	      if (bishopch (pos, xy, sq[i]) || rookch (pos, xy, sq[i]))
		return 0;
	    }
	}
    }
  return 1;
}


void
printpos (int pos[128], int ep, int castle)
{
  char s[13] = {
    'q', 'r', 'b', 'n', 'k', 'p', '-', 'P', 'K', 'N', 'B', 'R', 'Q'
  };
  int i, j;
  for (j = 7; j >= 0; j--)
    {
      for (i = 0; i < 8; i++)
	{
	  putchar (s[pos[(j << 4) + i] + 6]);
	}
      putchar (' ');
    }
  printf ("%d %d ", ep, castle);
  //putchar ('\n');
}

int
main (int argc, char **argv)
{
  long long tot = 0;
  int board[128], castle;
  POS p;
  POS2 q;

  int i = 0, j = 0, c, x, tt = 0;
  if (argc != 6)
    {
      printf ("usage: %s filein fileout depth opt stm\n", argv[0]);
      exit (1);
    }
  wanted = atoi (argv[3])+1;
  opt = atoi (argv[4]);
  stm = atoi (argv[5]);

  for (i = 0; i < 64; i++)
    for (j = 0; j < 13; j++)
      ran[i][j] = Random64 ();	/* hash table generation */
  c = 0;
  for (i = 0; i < 8; i++)
    {
      for (j = 0; j < 8; j++)
	sq[c++] = (i << 4) + j;
    }
  in = fopen (argv[1], "rb");
  if (!in) { printf("error opening infile\n"); exit(1); }
  out = fopen( argv[2],"wb");
  if (!out) { printf("error opening outfile\n"); exit(1); }
  while (1)
    { readpos (&p, in);
      if (feof (in))
	break;
        tt++;
      q = getpos (&p);
      qc = q.count;
      tot+=q.count*generate (q.pos, 0, stm, q.ep, q.castle);
    }
  fclose (in);
  tree_disp(&postree);
  fclose (out);
  printf ("%lld %lld %d\n", dup,tot,tt);
  return 0;
}

int
CompPos (POS * p1, POS * p2)
{
  int i;
  for (i = 0; i < 8; i++)
    {
      if (p1->rank[i] < p2->rank[i])
	return -1;
      if (p1->rank[i] > p2->rank[i])
	return 1;
    }
  if (p1->epc > p2->epc)
    return 1;
  if (p1->epc < p2->epc)
    return -1;
  return (0);
}

void
setpos (POS * p, int pos[128], char ep, char castle, int count)
{
  int i, j;
  for (i = 0; i < 8; i++)
    {
      p->rank[i] = 0;
      for (j = 0; j < 8; j++)
	p->rank[i] += (pos[(j << 4) + i] + 7) << (j << 2);
    }
   if (ep)
    ep = (ep & 0x07) + 1; 	/* either 0 or 1..8 */
  p->epc = (ep << 4) + castle;
  p->count = count;
}

unsigned int
Random32 (void)
{
  /*
     random numbers from Mathematica 2.0.
     SeedRandom = 1;
     Table[Random[Integer, {0, 2^32 - 1}]
   */
  static const unsigned long x[55] = {
    1410651636UL, 3012776752UL, 3497475623UL, 2892145026UL, 1571949714UL,
    3253082284UL, 3489895018UL, 387949491UL, 2597396737UL, 1981903553UL,
    3160251843UL, 129444464UL, 1851443344UL, 4156445905UL, 224604922UL,
    1455067070UL, 3953493484UL, 1460937157UL, 2528362617UL, 317430674UL,
    3229354360UL, 117491133UL, 832845075UL, 1961600170UL, 1321557429UL,
    747750121UL, 545747446UL, 810476036UL, 503334515UL, 4088144633UL,
    2824216555UL, 3738252341UL, 3493754131UL, 3672533954UL, 29494241UL,
    1180928407UL, 4213624418UL, 33062851UL, 3221315737UL, 1145213552UL,
    2957984897UL, 4078668503UL, 2262661702UL, 65478801UL, 2527208841UL,
    1960622036UL, 315685891UL, 1196037864UL, 804614524UL, 1421733266UL,
    2017105031UL, 3882325900UL, 810735053UL, 384606609UL, 2393861397UL
  };
  static int init = 1;
  static unsigned long y[55];
  static int j, k;
  unsigned long ul;
  if (init)
    {
      int i;
      init = 0;
      for (i = 0; i < 55; i++)
	y[i] = x[i];
      j = 24 - 1;
      k = 55 - 1;
    }

  ul = (y[k] += y[j]);
  if (--j < 0)
    j = 55 - 1;
  if (--k < 0)
    k = 55 - 1;
  return ((unsigned int) ul);
}

unsigned long long
Random64 (void)
{
  unsigned long long result;
  unsigned int r1, r2;
  r1 = Random32 ();
  r2 = Random32 ();
  result = r1 | (unsigned long long) r2 << 32;
  return (result);
}

char
updatecastle (int pos[128], int s, char castle)
{
  //printf("u1 %d\n",castle);
  if (pos[0 + (7 << 4)] >= 0)	/* if white/empty on a8 ... */
    castle &= 14;		/* ... black can't castle q-side */
  if (pos[0 + (0 << 4)] <= 0)	/* if black/empty on a1 ... */
    castle &= 11;		/* white can't castle q-side */
  if (pos[7 + (7 << 4)] >= 0)	/* if white/empty on h8 ... */
    castle &= 13;		/* black can't castle k-side */
  if (pos[7 + (0 << 4)] <= 0)	/* if black/empty on h1 ... */
    castle &= 7;		/* white can't castle k-side */
  //printf("u2 %d\n",castle);
  return castle;
}

void
readpos (POS * p, FILE * f)
{
  fread (&(p->rank), 4, 8, f);
  fread (&(p->epc), 1, 1, f);
  fread (&(p->count), sizeof (int), 1, f);
}

void writepos (POS * p, FILE * f)
//void writepos ( long *rank, unsigned char *epc, int *count, FILE *f)
{
 fwrite (&(p->rank), 4, 8, f);
 fwrite (&(p->epc), 1, 1, f);
 fwrite (&(p->count), sizeof (int), 1, f);
}


POS2
getpos (POS * p)
{
  int i, j;
  POS2 q;
  for (i = 0; i < 8; i++)
    {
      unsigned long x = p->rank[i];
      for (j = 0; j < 8; j++)
	{
	  q.pos[i + (j << 4)] = (x & 15) - 7;
	  x >>= 4;
	}
    }
  q.ep = (p->epc) >> 4;
  if (q.ep)
    {
      q.ep -= 1;
      q.ep += 32;
      if (stm > 0)
	q.ep += 48;
    }

  q.castle = (p->epc) & 15;
  q.count = p->count;
  return q;
}
 
int tree_disp (tree ** ppr_tree)
{
  if (*ppr_tree)
      writepos((POS *) (**ppr_tree).data, out); 
  if (!*ppr_tree)
      return 1;
  if (!tree_disp (&(**ppr_tree).left))
    return 0;
  if (!(POS *) ((**ppr_tree).data))
    return 0;
  if (!tree_disp (&(**ppr_tree).right))
    return 0;
  return 1;
}
